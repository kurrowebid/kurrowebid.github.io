<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" lang="en">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>kurro.id</title>
	<!-- css -->
	<!--	<link rel="stylesheet" type="text/css" href="../assets/css/core-bundle.css">  -->
 <link rel="stylesheet" type="text/css" href="../assets/js/vendor/swiper/css/swiper.min.css">
	<link rel="stylesheet" type="text/css" href="../assets/js/vendor/air-datepicker/datepicker.css">
	<link rel="stylesheet" type="text/css" href="../assets/css/core.css">
</head>
</head>
<body>
	<?php include('./partial/navbar.php');?>

	<div class="content">
		<div class="register flex center hide-m jarallax">
			<div class="modal-form row flex wrap">

				<div class="col-sm-12 col-md-4 modal-form--left text-center">
					<div class="img--user big">
						<img src="../assets/images/img-user2.png" alt="" class="img-circle">
					</div>
					<h4 class="text-white">Let's get you set up</h4>
				

					<div class="have-account">
						<small>Belum punya Akun? <a href="#" class="link">Daftar disini</a></small>
					</div>
				</div>
				<div class="col-sm-12 col-md-8 modal-form--right">
					<form class="form-horizontal">




						<div class="form-group">
							<label class="control-label col-sm-12 col-md-3 medium"><small>Name</small></label>
							<div class="col-sm-12 col-md-9">
								<input type="text" class="form-control" id="" placeholder="Enter URL">
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-sm-12 col-md-3 medium"><small>Kata Sandi</small></label>
							<div class="col-sm-12 col-md-9">
								<div class="show-password-wrapper">
									<input type="password" class="form-control" id="input-password-desktop" placeholder="Enter Password">
									<a href="javascript:void(0);" class="btn-show-password" onclick="showPasswordDesktop()"><i class="ico-show"></i></a>
								</div>
							</div>
						</div>
						<div class="form-group"> 
							<div class="col-sm-offset-2 col-sm-10 text-right">
								<a href="#" class="link"><small>Forgot Password?</small></a>
							</div>
						</div>
						<div class="form-group"> 
							<div class="col-sm-offset-2 col-sm-10">
								<input type="submit" class="btn btn--primary uppercase pull-right" value="submit">
								<button type="button" class="btn btn--primary3 uppercase pull-right margin-x10">cancel</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>

		<div class="m-register show-m">
			<div class="row flex wrap margin0">

				<div class="col-sm-12">
					<form action="">
						<div class="form text-center">

							<div class="form-wrapper">
								<div class="form-group text-left">
									<label class="control-label medium"><small>Email</small></label>
									<input type="text" class="form-control" id="" placeholder="Enter Email">
								</div>
								<div class="form-group text-left">
									<div class="flex vcenter between">
										<label class="control-labelmedium"><small>Password</small></label>
										<a href="#" class="link"><small>lupa password?</small></a>
									</div>
									<div class="show-password-wrapper">
										<input type="password" class="form-control" id="input-password-mobile" placeholder="Enter Password">
										<a href="javascript:void(0);" class="btn-show-password" onclick="showPasswordMobile()"><i class="ico-show"></i></a>
									</div>
								</div>
								<div class="form-group">
									<input type="submit" class="btn btn--primary btn-login uppercase" value="LOGIN">
								</div>
								<div class="form-group">
									<span>Belum punya akun? <a href="#" class="link"><b>Daftar</b></a></span>
								</div>
							</div>							
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>

<?php include('./partial/footer.php');?>
</body>

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
<script type="text/javascript" src="../assets/js/bootstrap/bootstrap.min.js"></script>
<script type="text/javascript" src="../assets/js/vendor/swiper/js/swiper.min.js"></script>
<script type="text/javascript" src="../assets/js/vendor/air-datepicker/datepicker.min.js"></script>
<script type="text/javascript" src="../assets/js/vendor/air-datepicker/datepicker.en.js"></script>

<script type="text/javascript" src="../../assets/js/script.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jarallax/2.1.4/jarallax.min.js"></script>
<script>jQuery(document).ready(function(){jQuery('.jarallax').jarallax({ speed: 0.5});})</script>
</html>