<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" lang="en">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<title>kurro.id</title>
	<meta name="author" content="">
	<meta name="keywords" content="">
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link rel="stylesheet" type="text/css" href="../assets/css/core-bundle.css"> 
<!--	<link rel="stylesheet" type="text/css" href="../assets/js/vendor/swiper/css/swiper.min.css">
	<link rel="stylesheet" type="text/css" href="../assets/js/vendor/air-datepicker/datepicker.css">
	<link rel="stylesheet" type="text/css" href="../assets/css/core.css">  -->
</head>
<body>
	<?php include('./partial/navbar.php');?>

	<div class="content">
		<div class="register bg-white">
			<div class="container">

				<br><br>
			</div>
			<div class="wizard-form" id="rootwizard">
				<div class="navbar">
					<div class="navbar-inner">
						<div class="flex center">
							<ul>
								<li><a href="#tab1" data-toggle="tab">Data Diri</a></li>
								<li><a href="#tab2" data-toggle="tab">Pengalaman Kerja</a></li>
								<li><a href="#tab3" data-toggle="tab">Informasi Tambahan</a></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="container">
					<div class="tab-content">
						<div class="tab-pane" id="tab1">
							<div class="box">
								<div class="box-content">
									<div class="row">
										<div class="col-md-4">
											<div class="flex center">
												<div class="upload-image-wrapper mt_30 mb_30">
													<div class="flex center vcenter">
														<input type="file" class="upload-image" id="imageUpload" name="files[]">
														<label for="imageUpload" class="upload-image-label" id="imageUploadLabel"></label>
													</div>
													<small class="d-block text-center mt_10">file jpg/png max 500kb</small>
												</div>
											</div>
										</div>
										<div class="col-md-8">
											<form class="form-horizontal">

												<div class="form-group">
													<label class="control-label col-sm-12 col-md-3 medium"><small>Nama Lengkap</small></label>
													<div class="col-sm-12 col-md-9">
														<input type="text" class="form-control text-validation" id="" placeholder="Nama lengkap">
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-12 col-md-3 medium"><small>Jenis Kelamin</small></label>
													<div class="col-sm-12 col-md-9">
														<div class="flex wrap">
															<div class="form-check mr_15">
																<input class="form-radio-input radio-validation" type="radio" name="radioGender" id="exampleRadios1" value="pria" checked>
																<label class="" for="exampleRadios1">Pria</label>
															</div>
															<div class="form-check">
																<input class="form-radio-input radio-validation" type="radio" name="radioGender" id="exampleRadios2" value="wanita">
																<label class="" for="exampleRadios2">Wanita</label>
															</div>
														</div>
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-12 col-md-3 medium"><small>Tanggal Lahir</small></label>
													<div class="col-sm-12 col-md-9">
														<div class="row">
															<div class="col-md-3 pr_5 xs-pr_15 xs-mb_15">
																<select name="" id="" class="form-control">
																	<option value="">01</option>
																	<option value="">02</option>
																</select>
															</div>
															<div class="col-md-3 pl_5 pr_5 xs-pl_15 xs-pr_15 xs-mb_15">
																<select name="" id="" class="form-control">
																	<option value="">01</option>
																	<option value="">02</option>
																</select>
															</div>
															<div class="col-md-6 pl_5 xs-pl_15 xs-mb_15">
																<select name="" id="" class="form-control">
																	<option value="">2000</option>
																	<option value="">2001</option>
																</select>
															</div>
														</div>
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-12 col-md-3 medium"><small>No Handphone</small></label>
													<div class="col-sm-12 col-md-9">
														<div class="row">
															<div class="col-md-4 col-xs-3 pr_5 xs-mb_15">
																<select name="" id="" class="form-control">
																	<option value="">+64</option>
																	<option value="">+86</option>
																</select>
															</div>
															<div class="col-md-8 col-xs-9 pl_5 xs-mb_15">
																<input type="number" class="form-control" id="" placeholder="87236346">
															</div>
														</div>
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-12 col-md-3 medium"><small>Domisili</small></label>
													<div class="col-sm-12 col-md-9">
														<textarea name="" class="form-control" id="" rows="5"></textarea>
													</div>
												</div>

												<br>
												<div class="summary-wrapper" id="add-more-summary">
													
												</div>
												<h2 class="form-title">Pendidikan</h2>
												<div class="add-more-form-wrapper">
													<div class="add-more-form">

														<div class="add-more-form-list">
															<div class="form-group">
																<label class="control-label col-sm-12 col-md-3 medium"><small>Jenjang Pendidikan</small></label>
																<div class="col-sm-12 col-md-9 pr_60">
																	<input type="text" class="form-control" id="inputEducation" placeholder="Jenjang pendidikan">
																</div>
															</div>
															<div class="form-group">
																<label class="control-label col-sm-12 col-md-3 medium"><small>Nama Universitas</small></label>
																<div class="col-sm-12 col-md-9 pr_60">
																	<input type="text" class="form-control" id="inputUniversityName" placeholder="Jenjang pendidikan">
																</div>
															</div>
															<div class="form-group">
																<label class="control-label col-sm-12 col-md-3 medium"><small>Jurusan</small></label>
																<div class="col-sm-12 col-md-9 pr_60">
																	<input type="text" class="form-control" id="inputDepartment" placeholder="Jenjang pendidikan">
																</div>
															</div>
															<div class="form-group">
																<label class="control-label col-sm-12 col-md-3 medium"><small>IPK</small></label>
																<div class="col-sm-12 col-md-9 pr_60">
																	<input type="text" class="form-control" id="inputGPA" placeholder="Jenjang pendidikan">
																</div>
															</div>
														</div>

													</div>
													<a href="#" class="btn-addmore plus-icon" id="add-more"><i class="fa fa-plus-circle" aria-hidden="true"></i></a>
												</div>

												<br>
												<h2 class="form-title">Pekerjaan</h2>
												<div class="form-group">
													<label class="control-label col-sm-12 col-md-3 medium"><small>Posisi</small></label>
													<div class="col-sm-12 col-md-9">
														<select name="" id="" class="form-control">
															<option value="">HRD</option>
															<option value="">IT</option>
														</select>
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-12 col-md-3 medium"><small>Ekspektasi Gaji</small></label>
													<div class="col-sm-12 col-md-9">
														<input type="text" class="form-control" id="" placeholder="Ekspektasi gaji">
													</div>
												</div>
											</form>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="tab-pane" id="tab2">
							<div class="box">
								<div class="box-content">
									<div class="row flex center wrap">
										<div class="col-md-8 col-xs-12">
											<form class="form-horizontal">

												<div class="form-group">
													<label class="control-label col-sm-12 col-md-3 medium"><small>Nama Perusahaan</small></label>
													<div class="col-sm-12 col-md-9">
														<input type="text" class="form-control" id="" placeholder="Nama perusahaan">
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-12 col-md-3 medium"><small>Nama Posisi</small></label>
													<div class="col-sm-12 col-md-9">
														<input type="text" class="form-control" id="" placeholder="Nama Posisi">
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-12 col-md-3 medium"><small>Function</small></label>
													<div class="col-sm-12 col-md-9">
														<input type="text" class="form-control" id="" placeholder="Function">
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-12 col-md-3 medium"><small>Level Posisi</small></label>
													<div class="col-sm-12 col-md-9">
														<input type="text" class="form-control" id="" placeholder="Level Posisi">
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-12 col-md-3 medium"><small>Gaji Terakhir</small></label>
													<div class="col-sm-12 col-md-9">
														<input type="text" class="form-control" id="" placeholder="Gaji terakhir">
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-12 col-md-3 medium"><small>Join Date</small></label>
													<div class="col-sm-12 col-md-9">
														<input type="text" class="form-control" id="" placeholder="Join Date">
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-12 col-md-3 medium"><small>End Date</small></label>
													<div class="col-sm-12 col-md-9">
														<input type="text" class="form-control" id="" placeholder="End date">
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-12 col-md-3 medium"><small>Present/Current</small></label>
													<div class="col-sm-12 col-md-9">
														<input type="text" class="form-control" id="" placeholder="Present/current">
													</div>
												</div>
											</form>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="tab-pane" id="tab3">
							<div class="box">
								<div class="box-content">
									<div class="row flex center wrap">
										<div class="col-md-8 col-xs-12">
											<form class="form-horizontal">

												<div class="form-group">
													<label class="control-label col-sm-12 col-md-4 medium"><small>No Identitas (KTP/KITAS</small></label>
													<div class="col-sm-12 col-md-8">
														<input type="text" class="form-control" id="" placeholder="Nama perusahaan">
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-12 col-md-4 medium"><small>Skill</small></label>
													<div class="col-sm-12 col-md-8">
														<input type="text" class="form-control" id="" placeholder="Nama Posisi">
													</div>
												</div>
												<div class="add-more-form-wrapper mb_15">
													<div class="add-more-form">
														<div class="form-group">
															<label class="control-label col-sm-12 col-md-4 medium"><small>Bahasa</small></label>
															<div class="col-sm-12 col-md-8 pr_60">
																<input type="text" class="form-control" id="" placeholder="Bahasa">
															</div>
														</div>
													</div>
													<a href="#" class="btn-addmore plus-icon"><i class="fa fa-plus-circle" aria-hidden="true"></i></a>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-12 col-md-4 medium"><small>Sertifikat</small></label>
													<div class="col-sm-12 col-md-8">
														<input type="text" class="form-control" id="" placeholder="Sertifikat">
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-12 col-md-4 medium"><small>Suku Etnis</small></label>
													<div class="col-sm-12 col-md-8">
														<input type="text" class="form-control" id="" placeholder="Level Posisi">
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-12 col-md-4 medium"><small>Agama</small></label>
													<div class="col-sm-12 col-md-8">
														<select name="" id="" class="form-control">
															<option value="">Islam</option>
															<option value="">Kristen</option>
															<option value="">Protestan</option>
															<option value="">Hindu</option>
															<option value="">Budha</option>
														</select>
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-12 col-md-4 medium"><small>Hobi</small></label>
													<div class="col-sm-12 col-md-8">
														<input type="text" class="form-control" id="" placeholder="Join Date">
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-12 col-md-4 medium"><small>Memiliki Kendaraan</small></label>
													<div class="col-sm-12 col-md-8">
														<div class="flex wrap">
															<div class="form-check mr_15">
																<input class="form-radio-input radio-validation" type="radio" name="memilikikendaraan" id="radioKendaraan1" value="ya" checked>
																<label class="" for="radioKendaraan1">Ya</label>
															</div>
															<div class="form-check">
																<input class="form-radio-input radio-validation" type="radio" name="memilikikendaraan" id="radioKendaraan2" value="tidak">
																<label class="" for="radioKendaraan2">Tidak</label>
															</div>
														</div>
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-12 col-md-4 medium"><small>Bersedia Melakukan Perjalanan Dinas</small></label>
													<div class="col-sm-12 col-md-8">
														<div class="flex wrap">
															<div class="form-check mr_15">
																<input class="form-radio-input radio-validation" type="radio" name="perjalanandinas" id="perjalananDinas1" value="pria" checked>
																<label class="" for="perjalananDinas1">Ya</label>
															</div>
															<div class="form-check">
																<input class="form-radio-input radio-validation" type="radio" name="perjalanandinas" id="perjalananDinas2" value="wanita">
																<label class="" for="perjalananDinas2">Tidak</label>
															</div>
														</div>
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-12 col-md-4 medium"><small>Kesiapan Bekerja</small></label>
													<div class="col-sm-12 col-md-8">
														<input type="text" class="form-control" id="" placeholder="Kesiapan bekerja">
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-12 col-md-4 medium"><small>Berencana melanjutkan pendidikan lagi?</small></label>
													<div class="col-sm-12 col-md-8">
														<div class="flex wrap">
															<div class="form-check mr_15">
																<input class="form-radio-input radio-validation" type="radio" name="lanjutpendidikan" id="lanjutPendidikan1" value="pria" checked>
																<label class="" for="lanjutPendidikan1">Ya</label>
															</div>
															<div class="form-check">
																<input class="form-radio-input radio-validation" type="radio" name="lanjutpendidikan" id="lanjutPendidikan2" value="wanita">
																<label class="" for="lanjutPendidikan2">Tidak</label>
															</div>
														</div>
													</div>
												</div>
											</form>
										</div>
									</div>
								</div>
							</div>
						</div>
						<ul class="pager wizard">
							<div class="flex between">
								<li class="previous btn-secondary"><a href="javascript:;">Previous</a></li>
								<div class="flex">
									<li class="next"><a href="javascript:;" class="btn-primary">Next</a></li>
									<li class="finish"><a href="javascript:;" class="btn-primary">Finish</a></li>
								</div>
							</div>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>

	<?php include('./partial/footer.php');?>
</body>

<script type="text/javascript" src="../assets/js/js-bundle.js"></script>
<script>

	$(document).ready(function() {
	  	$('#rootwizard').bootstrapWizard({onNext: function(tab, navigation, index) {
	  		
	  		var inputText = $('.text-validation');
	  		console.log(this);
	  		if(inputText.empty()) {
	  			inputText.parent().removeClass('has-error');
	  			inputText.parent().addClass('has-error');
	  			inputText.focus();
	  			return false;
	  		}

		}});
		$('#rootwizard .finish').click(function() {
			alert('Finished!, Starting over!');
			$('#rootwizard').find("a[href*='tab1']").trigger('click');
		});
		window.prettyPrint && prettyPrint();
	});

	$(document).ready(function() {
		if (window.File && window.FileList && window.FileReader) {
			$("#imageUpload").on("change", function(e) {
				var files = e.target.files,
				filesLength = files.length;

				var file = this.files[0];
				var fileType = file["type"];
				var validImageTypes = ["image/gif", "image/jpeg", "image/png"];
				if ($.inArray(fileType, validImageTypes) > 0) {
					
					for (var i = 0; i < filesLength; i++) {
						var f = files[i]
						var fileReader = new FileReader();
						fileReader.onload = (function(e) {
							var file = e.target;
							$("<span class=\"uploadImagePreview\">" +
								"<img class=\"uploadImageThumb\" src=\"" + e.target.result + "\" title=\"" + file.name + "\"/>" +
								"<br/><span class=\"removeUploadImage\">Remove image</span>" +
								"</span>").insertAfter("#imageUpload");
							$(".removeUploadImage").click(function(){
								$(this).parent(".uploadImagePreview").remove();
							});

						});
						fileReader.readAsDataURL(f);
					}

				}
			});
		} else {
			alert("Your browser doesn't support to File API")
		}
	});


	
	$('#add-more').on('click', function(e){
		e.preventDefault();

		var education = $('#inputEducation').val(),
			universityname = $('#inputUniversityName').val(),
			department = $('#inputDepartment').val(),
			gpa = $('#inputGPA').val(),
			index;

		var total_element = $(".summary-list").length;

		if(total_element == 0){
			index = 0;
		}
		else{
			var lastid = $(".summary-list:last").attr("id");
			var split_id = lastid.split("_");
			var nextindex = Number(split_id[1]) + 1;

			index = nextindex;
		}



		var template = '<div class="summary-list" id="div_' + index + '">' +
							'<span class="summary-list-remove btn btn-danger" id="remove_' + index + '">Remove</span>' +
							'<div class="inner-container">' +
								'<div class="summary-list-item">' +
									'<span class="summary-list-label">Jenjang Pendidikan</span>' +
									'<span class="summary-list-content">' + education + '</span>' +
								'</div>' +
								'<div class="summary-list-item">' +
									'<span class="summary-list-label">Nama Universitas</span>' +
									'<span class="summary-list-content">' + universityname + '</span>' +
								'</div>' +
								'<div class="summary-list-item">' +
									'<span class="summary-list-label">Jurusan</span>' +
									'<span class="summary-list-content">' + department + '</span>' +
								'</div>' +
								'<div class="summary-list-item">' +
									'<span class="summary-list-label">IPK</span>' +
									'<span class="summary-list-content">' + gpa + '</span>' +
								'</div>' +
							'</div>' +
						'</div>';

		$('#add-more-summary').append(template);

		// clear input
		$('#inputEducation').val('');
		$('#inputUniversityName').val('');
		$('#inputDepartment').val('');
		$('#inputGPA').val('');
	});	

	// Remove element
	 $('.summary-wrapper').on('click','.summary-list-remove',function(){
	 
	  var id = this.id;
	  var split_id = id.split("_");
	  var deleteindex = split_id[1];

	  // Remove <div> with id
	  $("#div_" + deleteindex).remove();

	 }); 
</script>
</html>