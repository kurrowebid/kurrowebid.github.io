<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" lang="en">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<title>kurro.id</title>
	<meta name="author" content="">
	<meta name="keywords" content="">
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- css -->
	<link rel="stylesheet" type="text/css" href="../assets/css/core-bundle.css">
	<!-- <link rel="stylesheet" type="text/css" href="../assets/js/vendor/swiper/css/swiper.min.css">
	<link rel="stylesheet" type="text/css" href="../assets/js/vendor/air-datepicker/datepicker.css">
	<link rel="stylesheet" type="text/css" href="../assets/css/core.css"> -->
</head>
<body>
	<?php include('./partial/navbar.php');?>

	<div class="content page__home">
		<!-- <div class="banner" style="background-image:url('../assets/images/img-banner.jpg')"></div> -->
		<div class="swiper-container home--slider">
			<div class="swiper-wrapper">
				<div class="swiper-slide slider-slide">
					<div class="img">
					<a href="https://wwww.kurro.id" target="_blank"><img src="../assets/images/img-banner.jpg" alt="" class="img-d"></a>	
						<img src="https://via.placeholder.com/728x480.png" alt="" class="img-m">
					</div>
				</div>
				<div class="swiper-slide slider-slide">
					<div class="img">
						<img src="../assets/images/img-banner2.jpg" alt="" class="img-d">
						<img src="https://via.placeholder.com/728x480.png" alt="" class="img-m">
					</div>
				</div>
				<!-- Add Pagination -->
				<div class="swiper-pagination"></div>
			</div>
		</div>
		<div class="jumbotron introduction margin0 bg--white">
			<div class="container">
				<h2 class="raleway spacing2 text-blue text-center uppercase mb_20 xs-mb-10">Job Fair Online</h2>
				<div class="row flex center">
					<div class="col-sm-6">
						<div class="desc center text-center">
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vero modi, beatae. Eum esse culpa, assumenda cumque deserunt nobis, eveniet fugit itaque, sunt nam asperiores provident saepe porro minus totam illo, commodi. Ut nam a, necessitatibus. Ipsa aspernatur harum, autem iste!</p>
						</div>	
					</div>
				</div>
				<div class="mt_40">
					<h3 class="raleway spacing4 text-blue text-center uppercase mb_30 xs-mb-16">Mengapa Kami</h3>
					<div class="row flex center">
						<div class="col-sm-6">
							<div class="feature-list">
								<div class="feature-list-item text-center mb_50">
									<div class="icon mb_25">
										<img src="../assets/images/icon1.png" alt="" class="d-inline-block" width="128">
									</div>
									<h4>Title</h4>
									<small>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Esse voluptate cum eveniet recusandae, praesentium quo delectus exercitationem, at ab officiis. Cupiditate ipsam libero nisi quam maiores deleniti, voluptas at provident!</small>
								</div>
								<div class="feature-list-item text-center mb_50">
									<div class="icon mb_25">
										<img src="../assets/images/icon4.png" alt="" class="d-inline-block" width="128">
									</div>
									<h4>Title</h4>
									<small>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Esse voluptate cum eveniet recusandae, praesentium quo delectus exercitationem, at ab officiis. Cupiditate ipsam libero nisi quam maiores deleniti, voluptas at provident!</small>
								</div>
								<div class="feature-list-item text-center mb_50">
									<div class="icon mb_25">
										<img src="../assets/images/icon3.png" alt="" class="d-inline-block" width="128">
									</div>
									<h4>Title</h4>
									<small>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Esse voluptate cum eveniet recusandae, praesentium quo delectus exercitationem, at ab officiis. Cupiditate ipsam libero nisi quam maiores deleniti, voluptas at provident!</small>
								</div>
							</div>	
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="jumbotron section-company margin0 bg--green">
			<div class="container">
				<h3 class="raleway spacing4 text-blue text-center uppercase mb_30 xs-mb-16">Perusahaan Partisipan</h3>
				<div class="swiper-container" id="company-list">
					<div class="swiper-wrapper">
						<div class="swiper-slide slider-slide">
							<div class="row flex wrap center">
								<div class="col-md-2 col-sm-3 col-xs-4">
									<div class="img" style="">
										<img src="../assets/images/logo/logo1.png" alt="">
									</div>
								</div>
								<div class="col-md-2 col-sm-3 col-xs-4">
									<div class="img" style="">
										<img src="../assets/images/logo/logo2.png" alt="">
									</div>
								</div>
								<div class="col-md-2 col-sm-3 col-xs-4">
									<div class="img" style="">
										<img src="../assets/images/logo/logo3.png" alt="">
									</div>
								</div>
								<div class="col-md-2 col-sm-3 col-xs-4">
									<div class="img" style="">
										<img src="../assets/images/logo/logo4.png" alt="">
									</div>
								</div>
								<div class="col-md-2 col-sm-3 col-xs-4">
									<div class="img" style="">
										<img src="../assets/images/logo/logo5.png" alt="">
									</div>
								</div>
								<div class="col-md-2 col-sm-3 col-xs-4">
									<div class="img" style="">
										<img src="../assets/images/logo/logo6.png" alt="">
									</div>
								</div>
								<div class="col-md-2 col-sm-3 col-xs-4">
									<div class="img" style="">
										<img src="../assets/images/logo/logo7.png" alt="">
									</div>
								</div>
								<div class="col-md-2 col-sm-3 col-xs-4">
									<div class="img" style="">
										<img src="../assets/images/logo/logo8.png" alt="">
									</div>
								</div>
								<div class="col-md-2 col-sm-3 col-xs-4">
									<div class="img" style="">
										<img src="../assets/images/logo/logo9.png" alt="">
									</div>
								</div>
								<div class="col-md-2 col-sm-3 col-xs-4">
									<div class="img" style="">
										<img src="../assets/images/logo/logo10.png" alt="">
									</div>
								</div>
								<div class="col-md-2 col-sm-3 col-xs-4">
									<div class="img" style="">
										<img src="../assets/images/logo/logo11.png" alt="">
									</div>
								</div>
								<div class="col-md-2 col-sm-3 col-xs-4">
									<div class="img" style="">
										<img src="../assets/images/logo/logo1.png" alt="">
									</div>
								</div>
							</div>
						</div>
						<div class="swiper-slide slider-slide">
							<div class="row flex wrap center">
								<div class="col-md-2 col-sm-3 col-xs-4">
									<div class="img" style="">
										<img src="../assets/images/logo/logo1.png" alt="">
									</div>
								</div>
								<div class="col-md-2 col-sm-3 col-xs-4">
									<div class="img" style="">
										<img src="../assets/images/logo/logo2.png" alt="">
									</div>
								</div>
								<div class="col-md-2 col-sm-3 col-xs-4">
									<div class="img" style="">
										<img src="../assets/images/logo/logo3.png" alt="">
									</div>
								</div>
								<div class="col-md-2 col-sm-3 col-xs-4">
									<div class="img" style="">
										<img src="../assets/images/logo/logo4.png" alt="">
									</div>
								</div>
								<div class="col-md-2 col-sm-3 col-xs-4">
									<div class="img" style="">
										<img src="../assets/images/logo/logo5.png" alt="">
									</div>
								</div>
								<div class="col-md-2 col-sm-3 col-xs-4">
									<div class="img" style="">
										<img src="../assets/images/logo/logo6.png" alt="">
									</div>
								</div>
								<div class="col-md-2 col-sm-3 col-xs-4">
									<div class="img" style="">
										<img src="../assets/images/logo/logo7.png" alt="">
									</div>
								</div>
								<div class="col-md-2 col-sm-3 col-xs-4">
									<div class="img" style="">
										<img src="../assets/images/logo/logo8.png" alt="">
									</div>
								</div>
								<div class="col-md-2 col-sm-3 col-xs-4">
									<div class="img" style="">
										<img src="../assets/images/logo/logo9.png" alt="">
									</div>
								</div>
								<div class="col-md-2 col-sm-3 col-xs-4">
									<div class="img" style="">
										<img src="../assets/images/logo/logo10.png" alt="">
									</div>
								</div>
								<div class="col-md-2 col-sm-3 col-xs-4">
									<div class="img" style="">
										<img src="../assets/images/logo/logo11.png" alt="">
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="jumbotron section2 margin0 bg--white">
			<div class="container text-center">
				<h3 class="raleway spacing4 text-blue">KATEGORI PEKERJAAN</h3>
				<br><br>
				<div class="row">
					<div class="col-md-3 col-sm-4 item__link">
						<a href="#" class="d-block">
							<div class="item__link--img">
								<div class="img" style="background-image: url(../assets/images/kategori/sprite.png);background-position: 0 0;"></div>
							</div>
							<h5 class="s15 spacing06">ACCOUNTING FINANCE / BANKING</h5>
						</a>
					</div>
					<div class="col-md-3 col-sm-4 item__link">
						<a href="#" class="d-block">
							<div class="item__link--img">
								<div class="img" style="background-image: url(../assets/images/kategori/sprite.png);background-position: -90px 0;"></div>
							</div>
							<h5 class="s15 spacing06">SALES / MARKETING</h5>
						</a>
					</div>
					<div class="col-md-3 col-sm-4 item__link">
						<a href="#" class="d-block">
							<div class="item__link--img">
								<div class="img" style="background-image: url(../assets/images/kategori/sprite.png);background-position: -180px 0;"></div>
							</div>
							<h5 class="s15 spacing06">COMPUTER / IT</h5>
						</a>
					</div>
					<div class="col-md-3 col-sm-4 item__link">
						<a href="#" class="d-block">
							<div class="item__link--img">
								<div class="img" style="background-image: url(../assets/images/kategori/sprite.png);background-position: -270px 0;"></div>
							</div>
							<h5 class="s15 spacing06">ART MEDIA / COMMUNICATIONS</h5>
						</a>
					</div>
					<div class="col-md-3 col-sm-4 item__link">
						<a href="#" class="d-block">
							<div class="item__link--img">
								<div class="img" style="background-image: url(../assets/images/kategori/sprite.png);background-position: -360px 0;"></div>
							</div>
							<h5 class="s15 spacing06">ADMIN / HUMAN RESOURCES</h5>
						</a>
					</div>
					<div class="col-md-3 col-sm-4 item__link">
						<a href="#" class="d-block">
							<div class="item__link--img">
								<div class="img" style="background-image: url(../assets/images/kategori/sprite.png);background-position: -450px 0;"></div>
							</div>
							<h5 class="s15 spacing06">CONSTRUCTION</h5>
						</a>
					</div>
					<div class="col-md-3 col-sm-4 item__link">
						<a href="#" class="d-block">
							<div class="item__link--img">
								<div class="img" style="background-image: url(../assets/images/kategori/sprite.png);background-position: -540px 0;"></div>
							</div>
							<h5 class="s15 spacing06">EDUCATION / TRAINNING</h5>
						</a>
					</div>
					<div class="col-md-3 col-sm-4 item__link">
						<a href="#" class="d-block">
							<div class="item__link--img">
								<div class="img" style="background-image: url(../assets/images/kategori/sprite.png);background-position: 0 -90px;"></div>
							</div>
							<h5 class="s15 spacing06">ENGINEERING</h5>
						</a>
					</div>
					<div class="col-md-3 col-sm-4 item__link">
						<a href="#" class="d-block">
							<div class="item__link--img">
								<div class="img" style="background-image: url(../assets/images/kategori/sprite.png);background-position: -90px -90px;"></div>
							</div>
							<h5 class="s15 spacing06">MANUFACTURING</h5>
						</a>
					</div>
					<div class="col-md-3 col-sm-4 item__link">
						<a href="#" class="d-block">
							<div class="item__link--img">
								<div class="img" style="background-image: url(../assets/images/kategori/sprite.png);background-position: -180px -90px;"></div>
							</div>
							<h5 class="s15 spacing06">HEALTHCARE</h5>
						</a>
					</div>
					<div class="col-md-3 col-sm-4 item__link">
						<a href="#" class="d-block">
							<div class="item__link--img">
								<div class="img" style="background-image: url(../assets/images/kategori/sprite.png);background-position: -270px -90px;"></div>
							</div>
							<h5 class="s15 spacing06">HOTEL / RESTAURANT</h5>
						</a>
					</div>
					<div class="col-md-3 col-sm-4 item__link">
						<a href="#" class="d-block">
							<div class="item__link--img">
								<div class="img" style="background-image: url(../assets/images/kategori/sprite.png);background-position: -360px -90px;"></div>
							</div>
							<h5 class="s15 spacing06">SCIENCE</h5>
						</a>
					</div>
				</div>
			</div>
		</div>
		<div class="jumbotron section5 margin0">
			<div class="container">
				<h3 class="raleway spacing4 text-blue text-center">ARTIKEL</h3>
				<br><br>
				<div class="row">
					<div class="col-sm-6 col-md-4 col-lg-3">
						<div class="thumbnail">
							<a href="#" class="d-block">
								<div class="img" style="background-image:url(../assets/images/img-thumb2.jpg)"></div>
							</a>
							<div class="caption">
								<a href="#"><h6 class="raleway bold spacing2 uppercase margin-b5">Montana</h6></a>
								<div class="match-height">
									<h6 class="s13 margin0">Without music, life would be a mistake.</h6>
								</div>
								<hr class="margin0">
								<div class="media">
									<div class="media-left media-middle">
										<a href="#" class="d-block">
											<img class="media-object img-circle" src="../assets/images/img-user.png" alt="...">
										</a>
									</div>
									<div class="media-body">
										<a href="#"><h6 class="media-heading raleway spacing2 uppercase bold">Paul Rand</h6></a>
										<h6 class="s13 margin0">Art Director, Designer</h6>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-sm-6 col-md-4 col-lg-3">
						<div class="thumbnail">
							<a href="#" class="d-block">
								<div class="img" style="background-image:url(../assets/images/img-thumb2.jpg)"></div>
							</a>
							<div class="caption">
								<a href="#"><h6 class="raleway bold spacing2 uppercase margin-b5">Montana</h6></a>
								<div class="match-height">
									<h6 class="s13 margin0">Without music, life would be a mistake.</h6>
								</div>
								<hr class="margin0">
								<div class="media">
									<div class="media-left media-middle">
										<a href="#" class="d-block">
											<img class="media-object img-circle" src="../assets/images/img-user.png" alt="...">
										</a>
									</div>
									<div class="media-body">
										<a href="#"><h6 class="media-heading raleway spacing2 uppercase bold">Paul Rand</h6></a>
										<h6 class="s13 margin0">Art Director, Designer</h6>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-sm-6 col-md-4 col-lg-3">
						<div class="thumbnail">
							<a href="#" class="d-block">
								<div class="img" style="background-image:url(../assets/images/img-thumb2.jpg)"></div>
							</a>
							<div class="caption">
								<a href="#"><h6 class="raleway bold spacing2 uppercase margin-b5">Montana</h6></a>
								<div class="match-height">
									<h6 class="s13 margin0">Without music, life would be a mistake. Without music, life would be a mistake.</h6>
								</div>
								<hr class="margin0">
								<div class="media">
									<div class="media-left media-middle">
										<a href="#" class="d-block">
											<img class="media-object img-circle" src="../assets/images/img-user.png" alt="...">
										</a>
									</div>
									<div class="media-body">
										<a href="#"><h6 class="media-heading raleway spacing2 uppercase bold">Paul Rand</h6></a>
										<h6 class="s13 margin0">Art Director, Designer</h6>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-sm-6 col-md-4 col-lg-3">
						<div class="thumbnail">
							<a href="#" class="d-block">
								<div class="img" style="background-image:url(../assets/images/img-thumb2.jpg)"></div>
							</a>
							<div class="caption">
								<a href="#"><h6 class="raleway bold spacing2 uppercase margin-b5">Montana</h6></a>
								<div class="match-height">
									<h6 class="s13 margin0">Without music, life would be a mistake. Without music, life would be a mistake.</h6>
								</div>
								<hr class="margin0">
								<div class="media">
									<div class="media-left media-middle">
										<a href="#" class="d-block">
											<img class="media-object img-circle" src="../assets/images/img-user.png" alt="...">
										</a>
									</div>
									<div class="media-body">
										<a href="#"><h6 class="media-heading raleway spacing2 uppercase bold">Paul Rand</h6></a>
										<h6 class="s13 margin0">Art Director, Designer</h6>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<?php include('./partial/footer.php');?>
</body>

<script type="text/javascript" src="../assets/js/js-bundle.js"></script>
<script>
	
	var swiper = new Swiper('#company-list', {
	    paginationClickable: true,
	    pagination: '.swiper-pagination',
	    spaceBetween: 30,
	    loop: true,
	    autoplay: 5000,
	    speed: 1200,
	  });
	
</script>
</html>