<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" lang="en">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<title>kurro.id</title>
	<meta name="author" content="">
	<meta name="keywords" content="">
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- css -->
	<!-- <link rel="stylesheet" type="text/css" href="../assets/js/vendor/swiper/css/swiper.min.css">
	<link rel="stylesheet" type="text/css" href="../assets/js/vendor/air-datepicker/datepicker.css"> -->
	<link rel="stylesheet" type="text/css" href="../assets/css/core-bundle.css">
</head>
<body>
	<?php include('./partial/navbar.php');?>

	<div class="content">
		<div class="banner" style="background-image:url('../assets/images/img-banner.jpg');"></div>
		<div class="container">
			<div class="row margin-b15">
				<div class="col-md-12">
					<div class="box text-center profile--header">
						<a href="#" class="img--user big edit-profile-picture" data-toggle="modal" data-target="#change-pp">
							<img src="../assets/images/img-user.png" alt="" class="">
						</a>
						<h2 class="s30 raleway bold margin-b5">Johnson Dominic</h2>
						<h4 class="s19 raleway margin-b10">Creative Designer</h4>
						<h5 class="s15 raleway">Relatio Tech - Universitas Gunadarma</h5>
						<div class="margin-y20">
							<div class="tag--2 d-inline-block margin-x5">
								<small><span>21</span>connections</small>
							</div>
							<div class="tag--2 d-inline-block margin-x5">
								<small><span>182</span>followers</small>
							</div>
						</div>

						<div class="dropdown upload__dropdown">
							<button class="btn btn--primary dropdown-toggle" type="button" data-toggle="dropdown">upload cv</button>
							<ul class="dropdown-menu dropdown-menu-right">
								<li><a href="#" class="text-right storage" data-toggle="modal" data-target="#upload-cv"><small class="semibold">from storage</small></a></li>
								<li><a href="#" class="text-right gdrive" data-toggle="modal" data-target="#upload-cv"><small class="semibold">from drive</small></a></li>
								<li><a href="#" class="text-right dropbox" data-toggle="modal" data-target="#upload-cv"><small class="semibold">from dropbox</small></a></li>
							</ul>
						</div>
					</div>
					<ul class="menu-nav">
						<li class="active"><a href="#">Public Profile</a></li>
						<li><a href="#">Saved Jobs</a></li>
						<li><a href="#">Account Settings</a></li>
						<li><a href="#">Jobs Applied</a></li>
						<li class="has-notif"><a href="#">Matched Jobs</a></li>
					</ul>
				</div>
			</div>
			<div class="row profile--body">
				<div class="col-content">
					<div class="section padding-y15">
						<div class="box">
							<div class="box__container">
								<div class="flex between vcenter">
									<h4 class="s19 raleway margin0">About me</h4>
									<a href="#" class="btn btn--primary2">EDIT</a>
								</div>
								<div class="margin-y15">
									<small>
										Lorem ipsum dolor sit amet, consectetur adipisicing elit. Possimus obcaecati velit necessitatibus corporis deserunt odio repellendus perspiciatis fugiat pariatur dolorum, iure quibusdam animi et nam molestiae error eligendi totam natus.
										<br><br>
										Lorem ipsum dolor sit amet, consectetur adipisicing elit. Natus voluptate recusandae alias iusto, doloremque animi sequi itaque consectetur error eum harum, beatae maxime, eveniet repellat provident vitae voluptatum, explicabo laboriosam!
									</small>
								</div>
							</div>
						</div>
					</div>
					<div class="section padding-y15">
						<div class="box">
							<div class="box__container">
								<div class="flex between vcenter">
									<h4 class="s19 raleway margin0">Working Experience</h4>
									<a href="#" class="btn btn--primary2">+ ADD MORE</a>
								</div>
								<ul class="media__wrapper">
									<li class="media margin0 padding-y15">
										<div class="media-left">
											<a href="#" class="media-img d-block">
												<img src="../assets/images/ico/ico-kurro.id.svg" alt="" class="media-object">
											</a>
										</div>
										<div class="media-body media-middle">
											<div class="col-md-9 col-sm-12 padding0">
												<h6 class="media-heading raleway bold">Lead Web Developer</h6>
												<small class="raleway d-block">kurro.id Tech - Jakarta</small>
												<small class="raleway d-block">Aug 2016 - Present</small>
											</div>
											<div class="col-md-3 col-sm-12 text-right padding0 dashboard--control">
												<div class="margin-b5">
													<a href="#" class="d-inline-block margin-r5">
														<svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 49 49" width="16px" height="16px" xml:space="preserve">
															<g style="fill: currentColor">
																<path d="M39.914,0H37.5h-28h-9v49h7h33h8V8.586L39.914,0z M35.5,2v14h-24V2H35.5z M9.5,47V28h29v19H9.5z M46.5,47h-6V26h-33v21h-5
																V2h7v16h28V2h1.586L46.5,9.414V47z"/>
																<path d="M13.5,33h7c0.553,0,1-0.447,1-1s-0.447-1-1-1h-7c-0.553,0-1,0.447-1,1S12.947,33,13.5,33z"/>
																<path d="M23.5,35h-10c-0.553,0-1,0.447-1,1s0.447,1,1,1h10c0.553,0,1-0.447,1-1S24.053,35,23.5,35z"/>
																<path d="M25.79,35.29c-0.181,0.189-0.29,0.45-0.29,0.71s0.109,0.52,0.29,0.71C25.979,36.89,26.229,37,26.5,37
																c0.26,0,0.52-0.11,0.71-0.29c0.18-0.19,0.29-0.45,0.29-0.71s-0.11-0.521-0.29-0.71C26.84,34.92,26.16,34.92,25.79,35.29z"/>
																<path d="M33.5,4h-6v10h6V4z M31.5,12h-2V6h2V12z"/>
															</g>
														</svg>
													</a>
													<a href="#" class="d-inline-block" data-toggle="modal" data-target="#edit-profile">
														<svg viewBox="0 0 24 24" width="18px" height="18px" x="0" y="0" preserveAspectRatio="xMinYMin meet" class="ico-pencil">
															<g class="large-icon" style="fill: currentColor">
																<path d="M21.71,5L19,2.29a1,1,0,0,0-1.41,0L4,15.85,2,22l6.15-2L21.71,6.45A1,1,0,0,0,22,5.71,1,1,0,0,0,21.71,5ZM6.87,18.64l-1.5-1.5L15.92,6.57l1.5,1.5ZM18.09,7.41l-1.5-1.5,1.67-1.67,1.5,1.5Z"></path>
															</g>
														</svg>
													</a>
												</div>
												<h6 class="raleway d-block bold text-green">Rp. 15.000.000</h6>
											</div>
										</div>
										<p class="media-p line20"><small>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque fugit nemo voluptatem natus non hic velit, facilis obcaecati omnis eum optio esse, eaque modi vitae voluptatibus, quasi excepturi eos tenetur!</small></p>
									</li>
									<li class="media margin0 padding-y15">
										<div class="media-left">
											<a href="#" class="media-img d-block">
												<img src="../assets/images/ico/ico-kurro.id.svg" alt="" class="media-object">
											</a>
										</div>
										<div class="media-body media-middle">
											<div class="col-md-9 col-sm-12 padding0">
												<h6 class="media-heading raleway bold">Lead Web Developer</h6>
												<small class="raleway d-block">kurro.id Tech - Jakarta</small>
												<small class="raleway d-block">Aug 2016 - Present</small>
											</div>
											<div class="col-md-3 col-sm-12 text-right padding0 dashboard--control">
												<a href="#" class="d-block margin-b5" data-toggle="modal" data-target="#edit-profile">
													<svg viewBox="0 0 24 24" width="18px" height="18px" x="0" y="0" preserveAspectRatio="xMinYMin meet" class="ico-pencil">
														<g class="large-icon" style="fill: currentColor">
															<path d="M21.71,5L19,2.29a1,1,0,0,0-1.41,0L4,15.85,2,22l6.15-2L21.71,6.45A1,1,0,0,0,22,5.71,1,1,0,0,0,21.71,5ZM6.87,18.64l-1.5-1.5L15.92,6.57l1.5,1.5ZM18.09,7.41l-1.5-1.5,1.67-1.67,1.5,1.5Z"></path>
														</g>
													</svg>
												</a>
												<h6 class="raleway d-block bold text-green">Rp. 10.000.000</h6>
											</div>
										</div>
									</li>
								</ul>
							</div>
						</div>
					</div>
					<div class="section padding-y15">
						<div class="box">
							<div class="box__container">
								<div class="flex between vcenter">
									<h4 class="s19 raleway margin0">Education</h4>
									<a href="#" class="btn btn--primary2">+ ADD MORE</a>
								</div>
								<ul class="media__wrapper">
									<li class="media margin0 padding-y15">
										<div class="media-left">
											<a href="#" class="media-img d-block">
												<img src="../assets/images/ico/ico-kurro.id.svg" alt="" class="media-object">
											</a>
										</div>
										<div class="media-body media-middle">
											<div class="col-sm-9 col-xs-11 padding0">
												<h6 class="media-heading raleway bold">kurro.id University</h6>
												<small class="raleway d-block">Bachelor's Degree, Information Systems</small>
												<small class="raleway d-block">2015 - 2017</small>
											</div>
											<div class="col-sm-3 col-xs-1 text-right padding0">
												<a href="#" class="d-block margin-b5">
													<svg viewBox="0 0 24 24" width="18px" height="18px" x="0" y="0" preserveAspectRatio="xMinYMin meet" class="ico-pencil">
														<g class="large-icon" style="fill: currentColor">
															<path d="M21.71,5L19,2.29a1,1,0,0,0-1.41,0L4,15.85,2,22l6.15-2L21.71,6.45A1,1,0,0,0,22,5.71,1,1,0,0,0,21.71,5ZM6.87,18.64l-1.5-1.5L15.92,6.57l1.5,1.5ZM18.09,7.41l-1.5-1.5,1.67-1.67,1.5,1.5Z"></path>
														</g>
													</svg>
												</a>
											</div>
										</div>
									</li>
									<li class="media margin0 padding-y15">
										<div class="media-left">
											<a href="#" class="media-img d-block">
												<img src="../assets/images/ico/ico-kurro.id.svg" alt="" class="media-object">
											</a>
										</div>
										<div class="media-body media-middle">
											<div class="col-sm-9 col-xs-11 padding0">
												<h6 class="media-heading raleway bold">kurro.id University</h6>
												<small class="raleway d-block">D3 Business Management</small>
												<small class="raleway d-block">2014 - 2015</small>
											</div>
											<div class="col-sm-3 col-xs-1 text-right padding0">
												<a href="#" class="d-block margin-b5">
													<svg viewBox="0 0 24 24" width="18px" height="18px" x="0" y="0" preserveAspectRatio="xMinYMin meet" class="ico-pencil">
														<g class="large-icon" style="fill: currentColor">
															<path d="M21.71,5L19,2.29a1,1,0,0,0-1.41,0L4,15.85,2,22l6.15-2L21.71,6.45A1,1,0,0,0,22,5.71,1,1,0,0,0,21.71,5ZM6.87,18.64l-1.5-1.5L15.92,6.57l1.5,1.5ZM18.09,7.41l-1.5-1.5,1.67-1.67,1.5,1.5Z"></path>
														</g>
													</svg>
												</a>
											</div>
										</div>
									</li>
								</ul>
							</div>
						</div>
					</div>
					<div class="section padding-y15">
						<div class="box">
							<div class="box__container">
								<div class="flex between vcenter">
									<h4 class="s19 raleway margin0">Skillsets</h4>
									<a href="#" class="d-block">
										<svg viewBox="0 0 24 24" width="18px" height="18px" x="0" y="0" preserveAspectRatio="xMinYMin meet" class="ico-pencil">
											<g class="large-icon" style="fill: currentColor">
												<path d="M21.71,5L19,2.29a1,1,0,0,0-1.41,0L4,15.85,2,22l6.15-2L21.71,6.45A1,1,0,0,0,22,5.71,1,1,0,0,0,21.71,5ZM6.87,18.64l-1.5-1.5L15.92,6.57l1.5,1.5ZM18.09,7.41l-1.5-1.5,1.67-1.67,1.5,1.5Z"></path>
											</g>
										</svg>
									</a>
								</div>
								<ul class="tag__wrapper">
									<li class="tag tag--inline uppercase">CSS</li>
									<li class="tag tag--inline uppercase">HTML</li>
									<li class="tag tag--inline uppercase">PHP</li>
									<a href="#" class="tag tag--inline btn--addtag">+</a>
								</ul>
							</div>
						</div>
					</div>
					<div class="section padding-y15">
						<div class="box">
							<div class="box__container">
								<div class="flex between vcenter">
									<h4 class="s19 raleway margin0">Bahasa</h4>
									<a href="#" class="btn btn--primary2">+ ADD MORE</a>
								</div>
								<ul class="media__wrapper">
									<li class="media margin0 padding-y15">
										<div class="flex between vcenter">
											<h6 class="media-heading margin0 raleway bold">English</h6>
											<a href="#" class="d-block">
												<i class="ico-cross"></i>
											</a>
										</div>
									</li>
									<li class="media margin0 padding-y15">
										<div class="flex between vcenter">
											<h6 class="media-heading margin0 raleway bold">Spanyol</h6>
											<a href="#" class="d-block">
												<i class="ico-cross"></i>
											</a>
										</div>
									</li>
									<li class="media margin0 padding-y15">
										<div class="flex between vcenter">
											<h6 class="media-heading margin0 raleway bold">Indonesia</h6>
											<a href="#" class="d-block">
												<i class="ico-cross"></i>
											</a>
										</div>
									</li>
								</ul>
							</div>
						</div>
					</div>
					<div class="section padding-y15">
						<div class="box">
							<div class="box__container">
								<div class="flex between vcenter">
									<h4 class="s19 raleway margin0">Additional Information</h4>
									<a href="#" class="d-block">
										<svg viewBox="0 0 24 24" width="18px" height="18px" x="0" y="0" preserveAspectRatio="xMinYMin meet" class="ico-pencil">
											<g class="large-icon" style="fill: currentColor">
												<path d="M21.71,5L19,2.29a1,1,0,0,0-1.41,0L4,15.85,2,22l6.15-2L21.71,6.45A1,1,0,0,0,22,5.71,1,1,0,0,0,21.71,5ZM6.87,18.64l-1.5-1.5L15.92,6.57l1.5,1.5ZM18.09,7.41l-1.5-1.5,1.67-1.67,1.5,1.5Z"></path>
											</g>
										</svg>
									</a>
								</div>
								<div class="margin-y15">
									<small class="raleway d-block">Email</small>
									<small class="raleway bold d-block">n5310_fadli@yahoo.com</small>
								</div>
								<div class="margin-y15">
									<small class="raleway d-block">Phone</small>
									<small class="raleway bold d-block">0812457815646</small>
								</div>
								<div class="margin-y15">
									<small class="raleway d-block">Birthday</small>
									<small class="raleway bold d-block">2 Februari 1988</small>
								</div>
								<div class="margin-y15">
									<small class="raleway d-block">Address</small>
									<small class="raleway bold d-block">Jakarta Barat, Indonesia</small>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-ads">
					<div class="section padding-y15">
						<div class="box">
							<div class="box__container">
								<div class="flex between">
									<h4 class="s19 raleway margin0"><span class="text-highlight text-green">21</span> Connections request</h4>
								</div>
								<ul class="media__wrapper">
									<li class="media margin0 padding-y15">
										<div class="media-left media-middle">
											<a href="#" class="media-img d-block">
												<img src="../assets/images/img-user.png" alt="" class="media-object img-circle">
											</a>
										</div>
										<div class="media-body media-middle">
											<a href="#" class="media-link">
												<h6 class="media-heading raleway bold">Toretto Michael</h6>
											</a>
											<small class="raleway d-block">Lead Mobile Developer at Seruput Berkah</small>
										</div>
									</li>
									<li class="media margin0 padding-y15">
										<div class="media-left media-middle">
											<a href="#" class="media-img d-block">
												<img src="../assets/images/img-user.png" alt="" class="media-object img-circle">
											</a>
										</div>
										<div class="media-body media-middle">
											<a href="#" class="media-link">
												<h6 class="media-heading raleway bold">Keaton Wayne</h6>
											</a>
											<small class="raleway d-block">Web Developer at Seruput Berkah</small>
										</div>
									</li>
									<li class="media margin0 padding-y15">
										<div class="media-left media-middle">
											<a href="#" class="media-img d-block">
												<img src="../assets/images/img-user.png" alt="" class="media-object img-circle">
											</a>
										</div>
										<div class="media-body media-middle">
											<a href="#" class="media-link">
												<h6 class="media-heading raleway bold">Baserin Cole</h6>
											</a>
											<small class="raleway d-block">Lead Marketing at Seruput Berkah</small>
										</div>
									</li>
								</ul>
								<div class="text-center margin10">
									<a href="#" class="btn btn--primary-rounded">see all</a>
								</div>
							</div>
						</div>
					</div>
					<div class="section padding-y15">
						<div class="box">
							<div class="box__container">
								<div class="flex between">
									<h4 class="s19 raleway margin0"><span class="text-highlight text-green">21</span> Profile viewers</h4>
								</div>
								<ul class="media__wrapper">
									<li class="media margin0 padding-y15">
										<div class="media-left media-middle">
											<a href="#" class="media-img d-block">
												<img src="../assets/images/img-user.png" alt="" class="media-object img-circle">
											</a>
										</div>
										<div class="media-body media-middle">
											<a href="#" class="media-link">
												<h6 class="media-heading raleway bold">Toretto Michael</h6>
											</a>
											<small class="raleway d-block">Lead Mobile Developer at Seruput Berkah</small>
										</div>
									</li>
									<li class="media margin0 padding-y15">
										<div class="media-left media-middle">
											<a href="#" class="media-img d-block">
												<img src="../assets/images/img-user.png" alt="" class="media-object img-circle">
											</a>
										</div>
										<div class="media-body media-middle">
											<a href="#" class="media-link">
												<h6 class="media-heading raleway bold">Keaton Wayne</h6>
											</a>
											<small class="raleway d-block">Web Developer at Seruput Berkah</small>
										</div>
									</li>
									<li class="media margin0 padding-y15">
										<div class="media-left media-middle">
											<a href="#" class="media-img d-block">
												<img src="../assets/images/img-user.png" alt="" class="media-object img-circle">
											</a>
										</div>
										<div class="media-body media-middle">
											<a href="#" class="media-link">
												<h6 class="media-heading raleway bold">Baserin Cole</h6>
											</a>
											<small class="raleway d-block">Lead Marketing at Seruput Berkah</small>
										</div>
									</li>
								</ul>
								<div class="text-center margin10">
									<a href="#" class="btn btn--primary-rounded">see all</a>
								</div>
							</div>
						</div>
					</div>
					<div class="section padding-y15">
						<div class="box">
							<div class="box__container">
								<div class="flex between">
									<h4 class="s19 raleway margin0"><span class="text-highlight text-green">21</span> Liked Resume</h4>
								</div>
								<ul class="media__wrapper">
									<li class="media margin0 padding-y15">
										<div class="media-left media-middle">
											<a href="#" class="media-img d-block">
												<img src="../assets/images/ico/ico-kurro.id.svg" alt="" class="media-object">
											</a>
										</div>
										<div class="media-body media-middle">
											<a href="#" class="media-link">
												<h6 class="media-heading raleway bold">kurro.id Tech</h6>
											</a>
											<small class="raleway d-block">for <span class="text-green">Java Programmer</span> vacancy</small>
										</div>
									</li>
									<li class="media margin0 padding-y15">
										<div class="media-left media-middle">
											<a href="#" class="media-img d-block">
												<img src="../assets/images/ico/ico-kurro.id.svg" alt="" class="media-object">
											</a>
										</div>
										<div class="media-body media-middle">
											<a href="#" class="media-link">
												<h6 class="media-heading raleway bold">kurro.id Tech</h6>
											</a>
											<small class="raleway d-block">for <span class="text-green">Java Programmer</span> vacancy</small>
										</div>
									</li>
								</ul>
								<div class="text-center margin10">
									<a href="#" class="btn btn--primary-rounded">see all</a>
								</div>
							</div>
						</div>
					</div>
					<div class="section padding-y15">
						<div class="box">
							<div class="box__container">
								<div class="flex between">
									<h4 class="s19 raleway margin0"><span class="text-highlight text-green">21</span> Liked Article</h4>
								</div>
								<ul class="media__wrapper">
									<li class="media margin0 padding-y15">
										<div class="media-left media-middle">
											<a href="#" class="media-img d-block">
												<img src="../assets/images/ico/ico-kurro.id.svg" alt="" class="media-object">
											</a>
										</div>
										<div class="media-body media-middle">
											<a href="#" class="media-link">
												<h6 class="media-heading raleway bold">How about your job?</h6>
											</a>
											<small class="raleway d-block"><span class="text-green">2</span> people like this</small>
										</div>
									</li>
									<li class="media margin0 padding-y15">
										<div class="media-left media-middle">
											<a href="#" class="media-img d-block">
												<img src="../assets/images/ico/ico-kurro.id.svg" alt="" class="media-object">
											</a>
										</div>
										<div class="media-body media-middle">
											<a href="#" class="media-link">
												<h6 class="media-heading raleway bold">Be ready if you hire a pro.</h6>
											</a>
											<small class="raleway d-block"><span class="text-green">100</span> people like this</small>
										</div>
									</li>
								</ul>
								<div class="text-center margin10">
									<a href="#" class="btn btn--primary-rounded">see all</a>
								</div>
							</div>
						</div>
					</div>
					<div class="section padding-y15">
						<div class="box">
							<div class="box__container">
								<div class="flex between">
									<h4 class="s19 raleway margin0"><span class="text-highlight text-green">2</span> Opened Resume</h4>
								</div>
								<ul class="media__wrapper">
									<li class="media margin0 padding-y15">
										<div class="media-left media-middle">
											<a href="#" class="media-img d-block">
												<img src="../assets/images/ico/ico-kurro.id.svg" alt="" class="media-object">
											</a>
										</div>
										<div class="media-body media-middle">
											<a href="#" class="media-link">
												<h6 class="media-heading raleway bold">kurro.id Tech</h6>
											</a>
											<small class="raleway d-block">for <span class="text-green">Java Programmer</span> vacancy</small>
										</div>
									</li>
									<li class="media margin0 padding-y15">
										<div class="media-left media-middle">
											<a href="#" class="media-img d-block">
												<img src="../assets/images/ico/ico-kurro.id.svg" alt="" class="media-object">
											</a>
										</div>
										<div class="media-body media-middle">
											<a href="#" class="media-link">
												<h6 class="media-heading raleway bold">kurro.id Tech</h6>
											</a>
											<small class="raleway d-block">for <span class="text-green">Java Programmer</span> vacancy</small>
										</div>
									</li>
								</ul>
								<div class="text-center margin10">
									<a href="#" class="btn btn--primary-rounded">see all</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<br><br>
		</div>
	</div>

	<div id="upload-cv" class="modal fade" role="dialog">
		<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-body">
					<h4 class="modal-title raleway">Upload by drive</h4>
					<form class="form-horizontal">
						<div class="form-group">
							<label class="control-label col-sm-12 col-md-4 medium"><small>Insert your drive link</small></label>
							<div class="col-sm-12 col-md-8">
								<input type="text" class="form-control" id="" placeholder="Enter URL">
							</div>
						</div>
						<div class="form-group"> 
							<div class="col-sm-offset-2 col-sm-10">
								<input type="submit" class="btn btn--primary uppercase pull-right" value="upload">
								<button type="button" class="btn btn--primary3 uppercase pull-right margin-x10" data-dismiss="modal">Close</button>
							</div>
						</div>
					</form>
				</div>
			</div>

		</div>
	</div>

	<div id="change-pp" class="modal stacked fade popup-change-profile-select" role="dialog" data-modal-index="1">
		<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-body">
					<h4 class="modal-title raleway">Change Profile Picture</h4>
					<form class="form-horizontal">
						<div class="form-group text-center margin0">
							<input type="file" id="select-image" class="btn-upload">
							<label for="select-image" class="btn-select-image">Please select image</label>
						</div>
						<div class="img-review-wrapper">
							<div class="form-group text-center margin0" id="imgReview">
								<img src="" alt="">
							</div>
							<div class="form-group margin-t15"> 
								<div class="col-sm-12 padding0">
									<button type="submit" class="btn btn--primary uppercase pull-right">Upload</button>
									<a href="javascript:void(0);" class="btn btn--primary2 btn-clear-upload uppercase pull-right margin-x10">Delete <i class="ico-delete"></i></a>
								</div>
							</div>
						</div>
					</form>
					<a href="javascript:void(0);" class="btn-close" data-dismiss="modal">&times;</a>
				</div>
			</div>

		</div>
	</div>

	<div id="change-pp-crop" class="modal stacked fade popup-change-profile-crop" data-modal-index="2">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-body">
					<form class="form-horizontal">
						<div class="form-group">
							<div class="img">
								<img src="" alt="" id="image" style="max-width: 100%;">
							</div>
						</div>
						<div class="form-group"> 
							<div class="col-sm-12 padding0">
								<a href="javascript:void(0);" class="btn btn--primary uppercase pull-right" id="cropImg">Crop</a>
								<button type="button" class="btn btn--primary3 uppercase pull-right margin-x10" data-dismiss="modal">Cancel</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>

	<div id="edit-profile" class="modal fade" role="dialog">
		<div class="modal-dialog modal-lg">
			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-body">
					<h4 class="modal-title raleway">Working Experience at <i class="text-green">kurro.id Tech</i></h4>
					<form class="">
						<div class="row">
							<div class="col-md-1">
								<img src="../assets/images/ico/ico-kurro.id.svg" alt="" class="media-object">
							</div>
							<div class="col-md-8">
								<div class="row">
									<div class="col-md-8">
										<div class="form-group">
											<label class="medium"><small>Company</small></label>
											<input type="text" class="form-control" id="" placeholder="Company Name">
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label class="medium"><small>Salary</small></label>
											<input type="text" class="form-control" id="" placeholder="Amount">
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-8">
										<div class="form-group">
											<label class="medium"><small>Position</small></label>
											<input type="text" class="form-control" id="" placeholder="Enter Position">
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-3">
										<div class="form-group">
											<label class="medium"><small>Periode</small></label>
											<input type="text" class="form-control" id="" placeholder="From">
										</div>
									</div>
									<div class="col-md-7">
										<label class="medium hidden-xs">&nbsp;</label>
										<div class="form-group">
											<input type="checkbox" class="check" id="check-1">
											<label for="check-1">I currently work here</label>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-12">
										<label><small>Explanations</small></label>
										<div class="form-group flex vcenter"> 
											<textarea class="form-control" rows="5" ></textarea>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-12">
										<div class="form-group flex vcenter"> 
											<input type="submit" class="btn btn--primary uppercase" value="save">
											<a href="#" class="link margin-x10" data-dismiss="modal"><small>Undo</small></a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</form>
				</div>
			</div>

		</div>
	</div>

<?php include('./partial/footer.php');?>
</body>

<!-- <script type="text/javascript" src="../assets/js/vendor/jquery.js"></script>
<script type="text/javascript" src="../assets/js/vendor/jquery.easing.min.js"></script>
<script type="text/javascript" src="../assets/js/bootstrap/bootstrap.min.js"></script>
<script type="text/javascript" src="../assets/js/vendor/swiper/js/swiper.min.js"></script>
<script type="text/javascript" src="../assets/js/vendor/air-datepicker/datepicker.min.js"></script>
<script type="text/javascript" src="../assets/js/vendor/air-datepicker/datepicker.en.js"></script> -->

<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBTeu43V4BOficz5PgyPoLNFWosb_6UnVg&callback=initMap"
type="text/javascript"></script>
<script type="text/javascript" src="../assets/js/js-bundle.js"></script>
<script type="text/javascript" src="../assets/js/vendor/scrollmagic/uncompressed/ScrollMagic.js"></script>
<script type="text/javascript" src="../assets/js/vendor/scrollmagic/uncompressed/plugins/debug.addIndicators.js"></script>
<script type="text/javascript" src="../assets/js/vendor/cropper/dist/cropper.js"></script>
<script>
	$(document).ready(function(){
		$('.filter--menu .btn--primary').on('click', function(){
			$('.button-close-filter--menu').click();
		});
	});

	var image = $('#image');

	$('#select-image').change(function(){
		if(this.files && this.files[0]){
			var reader = new FileReader();

			reader.onload = function(e){
				image.attr('src', e.target.result);
				$('#change-pp-crop').on('shown.bs.modal', function(){
					showCropper(image);
				})
				$('#change-pp-crop').modal('show');
			}

			reader.readAsDataURL(this.files[0]);
		}
	})

	$('#cropImg').on('click', function(){

		var imageData = image.cropper('getCroppedCanvas').toDataURL();
		$('#imgReview img').attr('src', imageData);
		$('#imgReview').parents('.img-review-wrapper').show();
		$('#change-pp-crop').modal('hide');
		reset(image);
	})


	$('.btn-clear-upload').on('click', function(){
		console.log('clear upload');
		$('#imgReview img').attr('src', '');
		$('#select-image').val('');
		$('#imgReview').parents('.img-review-wrapper').hide();
	});


	function reset(img){
		img.cropper('destroy');
		img.val('');
	}

	function showCropper(img){
		img.cropper({
			aspectRatio: 1 / 1,
			crop: function(event) {
				console.log(event.detail.x);
				console.log(event.detail.y);
				console.log(event.detail.width);
				console.log(event.detail.height);
				console.log(event.detail.rotate);
				console.log(event.detail.scaleX);
				console.log(event.detail.scaleY);
			}
		});
	}
</script>
<script type="text/javascript" src="../assets/js/script.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jarallax/2.1.4/jarallax.min.js"></script>
<script>jQuery(document).ready(function(){jQuery('.banner').jarallax({ speed: 0.5});})</script>
</html>