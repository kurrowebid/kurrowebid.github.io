<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" lang="en">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<title>kurro.id</title>
	<meta name="author" content="">
	<meta name="keywords" content="">
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- css -->
	<link rel="stylesheet" type="text/css" href="../assets/css/core-bundle.css">
	<!-- <link rel="stylesheet" type="text/css" href="../assets/js/vendor/swiper/css/swiper.min.css">
	<link rel="stylesheet" type="text/css" href="../assets/js/vendor/air-datepicker/datepicker.css">
	<link rel="stylesheet" type="text/css" href="../assets/css/core.css"> -->
</head>
<body>
	<?php include('./partial/navbar.php');?>


	<div class="content">
		<div class="banner jarallax" style="background-image:url('../assets/images/img-banner.jpg');"></div>
		<div class="container">
			<div class="row margin-b15">
				<div class="col-md-12">
					<div class="box profile--header2">
						<div class="media-left">
							<div class="img--user big">
								<img src="../assets/images/logo/logo2.png" alt="" class="">
							</div>
						</div>
						<div class="media-body">
							<div class="row">
								<div class="col-md-8 col-xs-12">
									<h2 class="s28 raleway bold margin-b5">PT. Red Bull Indonesia</h2>
								</div>
							</div>
							<div class="row flex margin-t10">
								<br>
								<div class="col-md-8 col-xs-12">
									<div class="margin-y10">
										<small class="raleway d-block">Industry</small>
										<small class="raleway bold d-block">Food & Beverage</small>
									</div>
									<div class="margin-y10">
										<small class="raleway d-block">Address</small>
										<small class="raleway bold d-block">Jl.Gatot Subroto Kav. 99, RT.2/RW.4, Mampang Prpt., Kec. Mampang Prpt., Kota Jakarta Selatan, Daerah Khusus Ibukota Jakarta 12790</small>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="row profile--body">
				<div class="col-content">
					<div class="section padding-y15">
						<div class="box">
							<div class="box__container">
								<div class="flex between padding-b10">
									<h4 class="s19 raleway margin0">Company Description</h4>
								</div>
								<p>
									Lorem ipsum dolor sit amet, consectetur adipisicing elit. Praesentium veniam nobis numquam obcaecati optio sequi dolor nulla culpa corrupti inventore accusantium cum beatae explicabo voluptas soluta blanditiis magni, aspernatur dolorum? <br>
									Lorem ipsum dolor sit amet, consectetur adipisicing elit. Illum debitis sint, magnam ipsam fugiat provident similique ut saepe, sunt est? <br>
									Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iusto iure temporibus quibusdam, cumque odio hic veniam officia fuga cum ex ducimus architecto ea commodi est voluptates ab vero explicabo possimus repellendus adipisci. Perferendis, accusamus aspernatur quam tempora nisi. Unde, dignissimos!
								</p>
							</div>
						</div>
					</div>
					<div class="section padding-y15">
						<div class="box">
							<div class="box__container">
								<div class="flex between padding-b10">
									<h4 class="s19 raleway margin0">Lowongan Kerja di PT. Red Bull Indonesia</h4>
								</div>
								<div class="">
									<div class="margin-y5">
										<div class="media margin0 padding15">
											<div class="media-left">
												<a href="#" class="media-img d-block">
													<img src="../assets/images/logo/logo2.png" alt="" class="media-object img-circle">
												</a>
											</div>
											<div class="media-body media-middle">
												<div class="col-sm-12 padding0">
													<a href="#" class="media-link">
														<h6 class="media-heading raleway bold">Mobile Developer App</h6>
													</a>
													<a href=""><small class="raleway d-block">PT. Red Bull Indonesia</small></a>
												</div>
												<ul class="margin0">
													<li class="d-inline-block margin-r10">
														<small><i class="text-green medium fa fa-map-marker margin-r5"></i>Kota Jakarta Selatan</small>
													</li>
													<li class="d-inline-block">
														<small><i class="text-green medium fa fa-usd margin-r5"></i>Rp. 1.000.000</small>
													</li>
												</ul>
												<p class="margin-y5">
													<small>Tanggung Jawab : Meng-input dan meng-update data karyawan baru, karyawan resign dan perubahan data lainnya pada sistem payroll. Meng-update roster karyawan. Memeriksa absensi dan overtime. Melakukan proses payroll bagi karyawan kontrak. Melakukan pengurusan BPJS (Ketenagakerjaan dan Kesehatan)</small>
												</p>
												<div class="col-md-12 padding0">
													<small class="s10"><i class="fa fa-clock-o" aria-hidden="true"></i> 20 jam yang lalu</small>
												</div>
											</div>
										</div>
									</div>
									<div class="margin-y5">
										<div class="media margin0 padding15">
											<div class="media-left">
												<a href="#" class="media-img d-block">
													<img src="../assets/images/logo/logo2.png" alt="" class="media-object img-circle">
												</a>
											</div>
											<div class="media-body media-middle">
												<div class="col-sm-12 padding0">
													<a href="#" class="media-link">
														<h6 class="media-heading raleway bold">Mobile Developer App</h6>
													</a>
													<a href=""><small class="raleway d-block">PT. Red Bull Indonesia</small></a>
												</div>
												<ul class="margin0">
													<li class="d-inline-block margin-r10">
														<small><i class="text-green medium fa fa-map-marker margin-r5"></i>Kota Jakarta Selatan</small>
													</li>
													<li class="d-inline-block">
														<small><i class="text-green medium fa fa-usd margin-r5"></i>Rp. 1.000.000</small>
													</li>
												</ul>
												<p class="margin-y5">
													<small>Tanggung Jawab : Meng-input dan meng-update data karyawan baru, karyawan resign dan perubahan data lainnya pada sistem payroll. Meng-update roster karyawan. Memeriksa absensi dan overtime. Melakukan proses payroll bagi karyawan kontrak. Melakukan pengurusan BPJS (Ketenagakerjaan dan Kesehatan)</small>
												</p>
												<div class="col-md-12 padding0">
													<small class="s10"><i class="fa fa-clock-o" aria-hidden="true"></i> 20 jam yang lalu</small>
												</div>
											</div>
										</div>
									</div>
									<div class="margin-y5">
										<div class="media margin0 padding15">
											<div class="media-left">
												<a href="#" class="media-img d-block">
													<img src="../assets/images/logo/logo2.png" alt="" class="media-object img-circle">
												</a>
											</div>
											<div class="media-body media-middle">
												<div class="col-sm-12 padding0">
													<a href="#" class="media-link">
														<h6 class="media-heading raleway bold">Mobile Developer App</h6>
													</a>
													<a href=""><small class="raleway d-block">PT. Red Bull Indonesia</small></a>
												</div>
												<ul class="margin0">
													<li class="d-inline-block margin-r10">
														<small><i class="text-green medium fa fa-map-marker margin-r5"></i>Kota Jakarta Selatan</small>
													</li>
													<li class="d-inline-block">
														<small><i class="text-green medium fa fa-usd margin-r5"></i>Rp. 1.000.000</small>
													</li>
												</ul>
												<p class="margin-y5">
													<small>Tanggung Jawab : Meng-input dan meng-update data karyawan baru, karyawan resign dan perubahan data lainnya pada sistem payroll. Meng-update roster karyawan. Memeriksa absensi dan overtime. Melakukan proses payroll bagi karyawan kontrak. Melakukan pengurusan BPJS (Ketenagakerjaan dan Kesehatan)</small>
												</p>
												<div class="col-md-12 padding0">
													<small class="s10"><i class="fa fa-clock-o" aria-hidden="true"></i> 20 jam yang lalu</small>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="pagination-centered">
						<nav aria-label="Page navigation">
							<ul class="pagination pagination-box">					
								<li id="page-button-0" class="active"><a href="#">1</a></li>
								<li id="page-button-1"><a href="#">2</a></li>
								<li id="page-button-2"><a href="#">3</a></li>
							</ul>
						</nav>
					</div>
				</div>
				<div class="col-ads">
					<div class="section padding-y15 section-ads">
						<div class="box">
							<div class="flex center vcenter" style="width:300px;height:250px;background-color:#00aaa7;color:#fff">ADD SPACE</div>
						</div>
					</div>
					<div class="section padding-y15 map">
						<div id="map"></div>
					</div>
				</div>
			</div>
			<br><br>
		</div>
	</div>

<?php include('./partial/footer.php');?>
</body>

<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBTeu43V4BOficz5PgyPoLNFWosb_6UnVg&callback=initMap"
type="text/javascript"></script>
<script type="text/javascript" src="../assets/js/js-bundle.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jarallax/2.1.4/jarallax.min.js"></script>
<script>jQuery(document).ready(function(){jQuery('.jarallax').jarallax({ speed: 0.5});})</script>
</html>