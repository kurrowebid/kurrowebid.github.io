<!DOCTYPE html>
<html>
<head>
	<title>kurro.id</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- css -->
	<link rel="stylesheet" type="text/css" href="../assets/js/vendor/swiper/css/swiper.min.css">
	<link rel="stylesheet" type="text/css" href="../assets/js/vendor/air-datepicker/datepicker.css">
	<link rel="stylesheet" type="text/css" href="../assets/css/core.css">
</head>
<body>
		<?php include('./partial/navbar.php');?>

	<div class="content">
		<div class="banner" style="background-image:url('../assets/images/img-banner.jpg');"></div>
		<div class="container">
			<div class="row margin-b15">
				<div class="col-md-12">
					<div class="box text-center profile--header">
						<a href="#" class="img--user big">
							<img src="../assets/images/img-user.png" alt="" class="">
						</a>
						<h2 class="s30 raleway bold margin-b5">Johnson Dominic</h2>
						<h4 class="s19 raleway margin-b10">Creative Designer</h4>
						<h5 class="s15 raleway">Relatio Tech - Universitas Gunadarma</h5>
						<div class="margin-y20">
							<div class="tag--2 d-inline-block margin-x5">
								<small><span>21</span>connections</small>
							</div>
							<div class="tag--2 d-inline-block margin-x5">
								<small><span>182</span>followers</small>
							</div>
						</div>

						<div class="dropdown upload__dropdown">
							<button class="btn btn--primary dropdown-toggle" type="button" data-toggle="dropdown">upload cv</button>
							<ul class="dropdown-menu dropdown-menu-right">
								<li><a href="#" class="text-right storage" data-toggle="modal" data-target="#upload-cv"><small class="semibold">from storage</small></a></li>
								<li><a href="#" class="text-right gdrive" data-toggle="modal" data-target="#upload-cv"><small class="semibold">from drive</small></a></li>
								<li><a href="#" class="text-right dropbox" data-toggle="modal" data-target="#upload-cv"><small class="semibold">from dropbox</small></a></li>
							</ul>
						</div>
					</div>
					<ul class="menu-nav">
						<li><a href="#">Public Profile</a></li>
						<li><a href="#">Saved Jobs</a></li>
						<li><a href="#">Account Settings</a></li>
						<li class="active"><a href="#">Jobs Applied</a></li>
						<li class="has-notif"><a href="#">Matched Jobs</a></li>
					</ul>
				</div>
			</div>
			<div class="row profile--body">
				<div class="col-content">
					<div class="section padding-y15">
						<div class="box">
							<div class="box__container">
								<div class="flex between">
									<h4 class="s19 raleway margin0"><span class="text-highlight text-green">2</span> Connections request</h4>
								</div>
								<ul class="media__wrapper">
									<li class="media margin0 padding-y15">
										<div class="media-left">
											<a href="#" class="media-img d-block">
												<img src="../assets/images/img-user.png" alt="" class="media-object img-circle">
											</a>
										</div>
										<div class="media-body media-middle">
											<div class="col-sm-7 col-md-8 padding0">
												<a href="#" class="media-link">
													<h6 class="media-heading raleway bold">Jeremy Tetty</h6>
												</a>
												<small class="raleway d-block">PT Seruput Berkah</small>
												<small class="raleway d-block"><i>201/2/2017</i></small>
											</div>
											<div class="col-sm-5 col-md-4 padding0 text-right">
												<a href="#" class="d-inline-block margin-x10"><i class="ico-cancel"></i></a>
												<a href="#" class="d-inline-block margin-x10"><i class="ico-accept"></i></a>
											</div>
										</div>
									</li>
								</ul>
							</div>
						</div>
					</div>
					<div class="section padding-y15">
						<div class="box">
							<div class="box__container padding15 text-center flex vcenter between">
								<a href="#" class="btn btn--primary-rounded2 btn--prev">PREVIOUS</a>
								<ul class="pagination margin0">
									<li><a href="#">1</a></li>
									<li><a href="#">2</a></li>
									<li class="active"><a href="#">3</a></li>
									<li><a href="#">4</a></li>
									<li><a href="#">5</a></li>
								</ul>
								<a href="#" class="btn btn--primary-rounded2 btn--next">NEXT</a>
							</div>
						</div>
					</div>
				</div>
				<div class="col-ads">
					<div class="section padding-y15">
						<div class="box">
							<div class="box__container">
								<div class="flex between">
									<h4 class="s19 raleway margin0"><span class="text-highlight text-green">21</span> Liked Resume</h4>
								</div>
								<ul class="media__wrapper">
									<li class="media margin0 padding-y15">
										<div class="media-left media-middle">
											<a href="#" class="media-img d-block">
												<img src="../assets/images/ico/ico-kurro.id.svg" alt="" class="media-object">
											</a>
										</div>
										<div class="media-body media-middle">
											<a href="#" class="media-link">
												<h6 class="media-heading raleway bold">kurro.id Tech</h6>
											</a>
											<small class="raleway d-block">for <span class="text-green">Java Programmer</span> vacancy</small>
										</div>
									</li>
									<li class="media margin0 padding-y15">
										<div class="media-left media-middle">
											<a href="#" class="media-img d-block">
												<img src="../assets/images/ico/ico-kurro.id.svg" alt="" class="media-object">
											</a>
										</div>
										<div class="media-body media-middle">
											<a href="#" class="media-link">
												<h6 class="media-heading raleway bold">kurro.id Tech</h6>
											</a>
											<small class="raleway d-block">for <span class="text-green">Java Programmer</span> vacancy</small>
										</div>
									</li>
								</ul>
								<div class="text-center margin10">
									<a href="#" class="btn btn--primary-rounded">see all</a>
								</div>
							</div>
						</div>
					</div>
					<div class="section padding-y15">
						<div class="box">
							<div class="box__container">
								<div class="flex between">
									<h4 class="s19 raleway margin0"><span class="text-highlight text-green">21</span> Liked Article</h4>
								</div>
								<ul class="media__wrapper">
									<li class="media margin0 padding-y15">
										<div class="media-left media-middle">
											<a href="#" class="media-img d-block">
												<img src="../assets/images/ico/ico-kurro.id.svg" alt="" class="media-object">
											</a>
										</div>
										<div class="media-body media-middle">
											<a href="#" class="media-link">
												<h6 class="media-heading raleway bold">How about your job?</h6>
											</a>
											<small class="raleway d-block"><span class="text-green">2</span> people like this</small>
										</div>
									</li>
									<li class="media margin0 padding-y15">
										<div class="media-left media-middle">
											<a href="#" class="media-img d-block">
												<img src="../assets/images/ico/ico-kurro.id.svg" alt="" class="media-object">
											</a>
										</div>
										<div class="media-body media-middle">
											<a href="#" class="media-link">
												<h6 class="media-heading raleway bold">Be ready if you hire a pro.</h6>
											</a>
											<small class="raleway d-block"><span class="text-green">100</span> people like this</small>
										</div>
									</li>
								</ul>
								<div class="text-center margin10">
									<a href="#" class="btn btn--primary-rounded">see all</a>
								</div>
							</div>
						</div>
					</div>
					<div class="section padding-y15">
						<div class="box">
							<div class="box__container">
								<div class="flex between">
									<h4 class="s19 raleway margin0"><span class="text-highlight text-green">2</span> Opened Resume</h4>
								</div>
								<ul class="media__wrapper">
									<li class="media margin0 padding-y15">
										<div class="media-left media-middle">
											<a href="#" class="media-img d-block">
												<img src="../assets/images/ico/ico-kurro.id.svg" alt="" class="media-object">
											</a>
										</div>
										<div class="media-body media-middle">
											<a href="#" class="media-link">
												<h6 class="media-heading raleway bold">kurro.id Tech</h6>
											</a>
											<small class="raleway d-block">for <span class="text-green">Java Programmer</span> vacancy</small>
										</div>
									</li>
									<li class="media margin0 padding-y15">
										<div class="media-left media-middle">
											<a href="#" class="media-img d-block">
												<img src="../assets/images/ico/ico-kurro.id.svg" alt="" class="media-object">
											</a>
										</div>
										<div class="media-body media-middle">
											<a href="#" class="media-link">
												<h6 class="media-heading raleway bold">kurro.id Tech</h6>
											</a>
											<small class="raleway d-block">for <span class="text-green">Java Programmer</span> vacancy</small>
										</div>
									</li>
								</ul>
								<div class="text-center margin10">
									<a href="#" class="btn btn--primary-rounded">see all</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<br><br>
		</div>
	</div>

<?php include('./partial/footer.php');?>
</body>

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
<script type="text/javascript" src="../assets/js/bootstrap/bootstrap.min.js"></script>
<script type="text/javascript" src="../assets/js/vendor/swiper/js/swiper.min.js"></script>
<script type="text/javascript" src="../assets/js/vendor/air-datepicker/datepicker.min.js"></script>
<script type="text/javascript" src="../assets/js/vendor/air-datepicker/datepicker.en.js"></script>

<script type="text/javascript" src="../../assets/js/script.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jarallax/2.1.4/jarallax.min.js"></script>
<script>jQuery(document).ready(function(){jQuery('.banner').jarallax({ speed: 0.5});})</script>
</html>