<?php include('./partial/header.php'); ?>

<div class="content">
	<div class="banner" style="background-image:url('../assets/images/img-banner.jpg');"></div>
	<div class="container">
		<div class="row margin-b15">
			<div class="col-md-12">
				<div class="box text-center profile--header">
					<a href="#" class="img--user big">
						<img src="../assets/images/img-user.png" alt="" class="">
					</a>
					<h2 class="s30 raleway bold margin-b5">Johnson Dominic</h2>
					<h4 class="s19 raleway margin-b10">Creative Designer</h4>
					<h5 class="s15 raleway">Relatio Tech - Universitas Gunadarma</h5>
				</div>
			</div>
		</div>
		<div class="row profile--body">
			<div class="col-content">
				<div class="section padding-y15">
					<div class="box">
						<div class="box__container">
							<div class="flex between">
								<h4 class="s19 raleway margin0">Working Experience</h4>
							</div>
							<ul class="media__wrapper">
								<li class="media margin0 padding-y15">
									<div class="media-left">
										<a href="#" class="media-img d-block">
											<img src="../assets/images/ico/ico-kurro.id.svg" alt="" class="media-object">
										</a>
									</div>
									<div class="media-body media-middle">
										<div class="col-xs-8 padding0">
											<h6 class="media-heading raleway bold">Lead Web Developer</h6>
											<small class="raleway d-block">kurro.id Tech - Jakarta</small>
											<small class="raleway d-block">Aug 2016 - Present</small>
										</div>
										<div class="col-xs-4 text-right padding0 dashboard--control">
											<h6 class="raleway d-block bold text-green">Rp. 15.000.000</h6>
										</div>
									</div>
									<p class="media-p line20"><small>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque fugit nemo voluptatem natus non hic velit, facilis obcaecati omnis eum optio esse, eaque modi vitae voluptatibus, quasi excepturi eos tenetur!</small></p>
								</li>
								<li class="media margin0 padding-y15">
									<div class="media-left">
										<a href="#" class="media-img d-block">
											<img src="../assets/images/ico/ico-kurro.id.svg" alt="" class="media-object">
										</a>
									</div>
									<div class="media-body media-middle">
										<div class="col-xs-8 padding0">
											<h6 class="media-heading raleway bold">Lead Web Developer</h6>
											<small class="raleway d-block">kurro.id Tech - Jakarta</small>
											<small class="raleway d-block">Aug 2016 - Present</small>
										</div>
										<div class="col-xs-4 text-right padding0 dashboard--control">
											<h6 class="raleway d-block bold text-green">Rp. 10.000.000</h6>
										</div>
									</div>
								</li>
							</ul>
						</div>
					</div>
				</div>
				<div class="section padding-y15">
					<div class="box">
						<div class="box__container">
							<div class="flex between">
								<h4 class="s19 raleway margin0">Education</h4>
							</div>
							<ul class="media__wrapper">
								<li class="media margin0 padding-y15">
									<div class="media-left media-middle">
										<a href="#" class="media-img d-block">
											<img src="../assets/images/ico/ico-kurro.id.svg" alt="" class="media-object">
										</a>
									</div>
									<div class="media-body media-middle">
										<h6 class="media-heading raleway bold">kurro.id University</h6>
										<small class="raleway d-block">Bachelor's Degree, Information Systems</small>
										<small class="raleway d-block">2015 - 2017</small>
									</div>
								</li>
								<li class="media margin0 padding-y15">
									<div class="media-left media-middle">
										<a href="#" class="media-img d-block">
											<img src="../assets/images/ico/ico-kurro.id.svg" alt="" class="media-object">
										</a>
									</div>
									<div class="media-body media-middle">
										<h6 class="media-heading raleway bold">kurro.id University</h6>
										<small class="raleway d-block">D3 Business Management</small>
										<small class="raleway d-block">2014 - 2015</small>
									</div>
								</li>
							</ul>
						</div>
					</div>
				</div>
				<div class="section padding-y15">
					<div class="box">
						<div class="box__container">
							<div class="flex between">
								<h4 class="s19 raleway margin0">Skillsets</h4>
							</div>
							<ul class="tag__wrapper">
								<li class="tag tag--inline uppercase">CSS</li>
								<li class="tag tag--inline uppercase">HTML</li>
								<li class="tag tag--inline uppercase">PHP</li>
							</ul>
						</div>
					</div>
				</div>
				<div class="section padding-y15">
					<div class="box">
						<div class="box__container">
							<div class="flex between">
								<h4 class="s19 raleway margin0">Bahasa</h4>
							</div>
							<ul class="media__wrapper">
								<li class="media margin0 padding-y15">
									<div class="media-body">
										<h6 class="media-heading margin0 raleway bold">English</h6>
									</div>
								</li>
								<li class="media margin0 padding-y15">
									<div class="media-body">
										<h6 class="media-heading margin0 raleway bold">Spanyol</h6>
									</div>
								</li>
								<li class="media margin0 padding-y15">
									<div class="media-body">
										<h6 class="media-heading margin0 raleway bold">Indonesia</h6>
									</div>
								</li>
							</ul>
						</div>
					</div>
				</div>
				<div class="section padding-y15">
					<div class="box">
						<div class="box__container">
							<div class="flex between">
								<h4 class="s19 raleway margin0">Additional Information</h4>
							</div>
							<div class="margin-y15">
								<small class="raleway d-block">Email</small>
								<small class="raleway bold d-block">n5310_fadli@yahoo.com</small>
							</div>
							<div class="margin-y15">
								<small class="raleway d-block">Phone</small>
								<small class="raleway bold d-block">0812457815646</small>
							</div>
							<div class="margin-y15">
								<small class="raleway d-block">Birthday</small>
								<small class="raleway bold d-block">2 Februari 1988</small>
							</div>
							<div class="margin-y15">
								<small class="raleway d-block">Address</small>
								<small class="raleway bold d-block">Jakarta Barat, Indonesia</small>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-ads">
				<div class="section padding-y15 section-ads">
					<div class="box">
						<div class="flex center vcenter" style="width:300px;height:250px;background-color:#00aaa7;color:#fff">ADD SPACE</div>
					</div>
				</div>
				<div class="section padding-y15">
					<div class="box">
						<div class="box__container">
							<div class="flex between">
								<h4 class="s19 raleway margin0">Alumni</h4>
							</div>
							<ul class="media__wrapper">
								<li class="media margin0 padding-y15">
									<div class="media-left media-middle">
										<a href="#" class="media-img d-block">
											<img src="../assets/images/ico/ico-kurro.id.svg" alt="" class="media-object">
										</a>
									</div>
									<div class="media-body media-middle">
										<a href="#" class="media-link">
											<h6 class="media-heading raleway bold">kurro.id University</h6>
										</a>
										<small class="raleway d-block">300 Applicants</small>
									</div>
								</li>
								<li class="media margin0 padding-y15">
									<div class="media-left media-middle">
										<a href="#" class="media-img d-block">
											<img src="../assets/images/ico/ico-kurro.id.svg" alt="" class="media-object">
										</a>
									</div>
									<div class="media-body media-middle">
										<a href="#" class="media-link">
											<h6 class="media-heading raleway bold">kurro.id University</h6>
										</a>
										<small class="raleway d-block">300 Applicants</small>
									</div>
								</li>
							</ul>
						</div>
					</div>
				</div>
				<div class="section padding-y15">
					<div class="box">
						<div class="box__container">
							<div class="flex between">
								<h4 class="s19 raleway margin0">People You May Know</h4>
							</div>
							<ul class="media__wrapper">
								<li class="media margin0 padding-y15">
									<div class="media-left media-middle">
										<a href="#" class="media-img d-block">
											<img src="../assets/images/img-user.png" alt="" class="media-object img-circle">
										</a>
									</div>
									<div class="media-body media-middle">
										<a href="#" class="media-link">
											<h6 class="media-heading raleway bold">Toretto Michael</h6>
										</a>
										<small class="raleway d-block">Lead Mobile Developer at Seruput Berkah</small>
									</div>
								</li>
								<li class="media margin0 padding-y15">
									<div class="media-left media-middle">
										<a href="#" class="media-img d-block">
											<img src="../assets/images/img-user.png" alt="" class="media-object img-circle">
										</a>
									</div>
									<div class="media-body media-middle">
										<a href="#" class="media-link">
											<h6 class="media-heading raleway bold">Keaton Wayne</h6>
										</a>
										<small class="raleway d-block">Web Developer at Seruput Berkah</small>
									</div>
								</li>
								<li class="media margin0 padding-y15">
									<div class="media-left media-middle">
										<a href="#" class="media-img d-block">
											<img src="../assets/images/img-user.png" alt="" class="media-object img-circle">
										</a>
									</div>
									<div class="media-body media-middle">
										<a href="#" class="media-link">
											<h6 class="media-heading raleway bold">Baserin Cole</h6>
										</a>
										<small class="raleway d-block">Lead Marketing at Seruput Berkah</small>
									</div>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
		<br><br>
	</div>
</div>

<?php include('./partial/footer.php'); ?>