<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" lang="en">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<title>kurro.id</title>
	<meta name="author" content="">
	<meta name="keywords" content="">
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- css -->
	<link rel="stylesheet" type="text/css" href="../assets/css/core-bundle.css">
</head>
<body>
	<?php include('./partial/navbar.php');?>
	<div class="content">
		<h1>404</h1>
		<h3>Page Not Found</h3>

		<form action="" class="form-inline">
			<div class="form-group job-position">
				<input type="text" class="form-control" placeholder="Job Position">
			</div>
			<div class="form-group job-location">
				<input type="text" class="form-control" placeholder="Job Location">
			</div>
			<input type="submit" class="btn btn--primary" value="FIND NOW">
		</form>
	</div>
	<?php include('./partial/footer.php');?>
</body>
<script type="text/javascript" src="../assets/js/js-bundle.js"></script>
</html>