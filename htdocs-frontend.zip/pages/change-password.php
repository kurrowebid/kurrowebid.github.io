<!DOCTYPE html>
<html>
<head>
	<title>kurro.id</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- css -->
	<link rel="stylesheet" type="text/css" href="../assets/js/vendor/swiper/css/swiper.min.css">
	<link rel="stylesheet" type="text/css" href="../assets/js/vendor/air-datepicker/datepicker.css">
	<link rel="stylesheet" type="text/css" href="../assets/css/core.css">
</head>
<body>
		<?php include('./partial/navbar.php');?>

	<div class="content">
		<div class="banner jarallax" style="background-image:url('../assets/images/img-banner.jpg');"></div>
		<div class="container">
			<div class="row margin-b15">
				<div class="col-md-12">
					<div class="box text-center profile--header">
						<a href="#" class="img--user big">
							<img src="../assets/images/img-user.png" alt="" class="">
						</a>
						<h2 class="s30 raleway bold margin-b5">Johnson Dominic</h2>
						<h4 class="s19 raleway margin-b10">Creative Designer</h4>
						<h5 class="s15 raleway">Relatio Tech - Universitas Gunadarma</h5>
						<div class="margin-y20">
							<div class="tag--2 d-inline-block margin-x5">
								<small><span>21</span>connections</small>
							</div>
							<div class="tag--2 d-inline-block margin-x5">
								<small><span>182</span>followers</small>
							</div>
						</div>

						<div class="dropdown upload__dropdown">
							<button class="btn btn--primary dropdown-toggle" type="button" data-toggle="dropdown">upload cv</button>
							<ul class="dropdown-menu dropdown-menu-right">
								<li><a href="#" class="text-right storage" data-toggle="modal" data-target="#upload-cv"><small class="semibold">from storage</small></a></li>
								<li><a href="#" class="text-right gdrive" data-toggle="modal" data-target="#upload-cv"><small class="semibold">from drive</small></a></li>
								<li><a href="#" class="text-right dropbox" data-toggle="modal" data-target="#upload-cv"><small class="semibold">from dropbox</small></a></li>
							</ul>
						</div>
					</div>
					<ul class="menu-nav">
						<li><a href="#">Public Profile</a></li>
						<li><a href="#">Saved Jobs</a></li>
						<li class="active"><a href="#">Account Settings</a></li>
						<li><a href="#">Jobs Applied</a></li>
						<li class="has-notif"><a href="#">Matched Jobs</a></li>
					</ul>
				</div>
			</div>
			<div class="row profile--body">
				<div class="col-content">
					<div class="section padding-y15">
						<div class="box">
							<div class="box__container">
								<div class="flex between">
									<h4 class="s19 raleway margin0">Change password</h4>
								</div>
								<br>
								<div class="alert alert-success alert-dismissable fade in">
									<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
									<strong>Success!</strong> This alert box could indicate a successful or positive action.
								</div>
								<div class="alert alert-danger alert-dismissable fade in">
									<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
									<strong>Danger!</strong> This alert box could indicate a dangerous or potentially negative action.
								</div>
								<form action="" class="form-horizontal">
									<div class="form-group">
										<label class="control-label col-sm-12 col-md-3 medium"><small>Old Password</small></label>
										<div class="col-sm-12 col-md-7">
											<input type="password" class="form-control" id="">
										</div>
									</div>
									<div class="form-group">
										<label class="control-label col-sm-12 col-md-3 medium"><small>New Password</small></label>
										<div class="col-sm-12 col-md-7">
											<input type="password" class="form-control" id="">
										</div>
									</div>
									<div class="form-group">
										<label class="control-label col-sm-12 col-md-3 medium"><small>Retype New Password</small></label>
										<div class="col-sm-12 col-md-7">
											<input type="password" class="form-control" id="">
										</div>
									</div>
									<div class="form-group"> 
										<div class="col-sm-offset-2 col-md-8 col-sm-10">
											<input type="submit" class="btn btn--primary uppercase pull-right" value="submit">
											<button type="button" class="btn btn--primary3 uppercase pull-right margin-x10">cancel</button>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
				<div class="col-ads">
					<div class="section padding-y15">
						<div class="box">
							<div class="box__container">
								<div class="flex between">
									<h4 class="s19 raleway margin0"><span class="text-highlight text-green">21</span> Liked Resume</h4>
								</div>
								<ul class="media__wrapper">
									<li class="media margin0 padding-y15">
										<div class="media-left media-middle">
											<a href="#" class="media-img d-block">
												<img src="../assets/images/ico/ico-kurro.id.svg" alt="" class="media-object">
											</a>
										</div>
										<div class="media-body media-middle">
											<a href="#" class="media-link">
												<h6 class="media-heading raleway bold">kurro.id Tech</h6>
											</a>
											<small class="raleway d-block">for <span class="text-green">Java Programmer</span> vacancy</small>
										</div>
									</li>
									<li class="media margin0 padding-y15">
										<div class="media-left media-middle">
											<a href="#" class="media-img d-block">
												<img src="../assets/images/ico/ico-kurro.id.svg" alt="" class="media-object">
											</a>
										</div>
										<div class="media-body media-middle">
											<a href="#" class="media-link">
												<h6 class="media-heading raleway bold">kurro.id Tech</h6>
											</a>
											<small class="raleway d-block">for <span class="text-green">Java Programmer</span> vacancy</small>
										</div>
									</li>
								</ul>
								<div class="text-center margin10">
									<a href="#" class="btn btn--primary-rounded">see all</a>
								</div>
							</div>
						</div>
					</div>
					<div class="section padding-y15">
						<div class="box">
							<div class="box__container">
								<div class="flex between">
									<h4 class="s19 raleway margin0"><span class="text-highlight text-green">21</span> Liked Article</h4>
								</div>
								<ul class="media__wrapper">
									<li class="media margin0 padding-y15">
										<div class="media-left media-middle">
											<a href="#" class="media-img d-block">
												<img src="../assets/images/ico/ico-kurro.id.svg" alt="" class="media-object">
											</a>
										</div>
										<div class="media-body media-middle">
											<a href="#" class="media-link">
												<h6 class="media-heading raleway bold">How about your job?</h6>
											</a>
											<small class="raleway d-block"><span class="text-green">2</span> people like this</small>
										</div>
									</li>
									<li class="media margin0 padding-y15">
										<div class="media-left media-middle">
											<a href="#" class="media-img d-block">
												<img src="../assets/images/ico/ico-kurro.id.svg" alt="" class="media-object">
											</a>
										</div>
										<div class="media-body media-middle">
											<a href="#" class="media-link">
												<h6 class="media-heading raleway bold">Be ready if you hire a pro.</h6>
											</a>
											<small class="raleway d-block"><span class="text-green">100</span> people like this</small>
										</div>
									</li>
								</ul>
								<div class="text-center margin10">
									<a href="#" class="btn btn--primary-rounded">see all</a>
								</div>
							</div>
						</div>
					</div>
					<div class="section padding-y15">
						<div class="box">
							<div class="box__container">
								<div class="flex between">
									<h4 class="s19 raleway margin0"><span class="text-highlight text-green">2</span> Opened Resume</h4>
								</div>
								<ul class="media__wrapper">
									<li class="media margin0 padding-y15">
										<div class="media-left media-middle">
											<a href="#" class="media-img d-block">
												<img src="../assets/images/ico/ico-kurro.id.svg" alt="" class="media-object">
											</a>
										</div>
										<div class="media-body media-middle">
											<a href="#" class="media-link">
												<h6 class="media-heading raleway bold">kurro.id Tech</h6>
											</a>
											<small class="raleway d-block">for <span class="text-green">Java Programmer</span> vacancy</small>
										</div>
									</li>
									<li class="media margin0 padding-y15">
										<div class="media-left media-middle">
											<a href="#" class="media-img d-block">
												<img src="../assets/images/ico/ico-kurro.id.svg" alt="" class="media-object">
											</a>
										</div>
										<div class="media-body media-middle">
											<a href="#" class="media-link">
												<h6 class="media-heading raleway bold">kurro.id Tech</h6>
											</a>
											<small class="raleway d-block">for <span class="text-green">Java Programmer</span> vacancy</small>
										</div>
									</li>
								</ul>
								<div class="text-center margin10">
									<a href="#" class="btn btn--primary-rounded">see all</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<br><br>
		</div>
	</div>

<?php include('./partial/footer.php');?>
</body>

<script type="text/javascript" src="../assets/js/vendor/jquery.js"></script>
<script type="text/javascript" src="../assets/js/vendor/jquery.easing.min.js"></script>
<script type="text/javascript" src="../assets/js/bootstrap/bootstrap.min.js"></script>
<script type="text/javascript" src="../assets/js/vendor/swiper/js/swiper.min.js"></script>
<script type="text/javascript" src="../assets/js/vendor/air-datepicker/datepicker.min.js"></script>
<script type="text/javascript" src="../assets/js/vendor/air-datepicker/datepicker.en.js"></script>

<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBTeu43V4BOficz5PgyPoLNFWosb_6UnVg&callback=initMap"
type="text/javascript"></script>

<script type="text/javascript" src="../assets/js/script.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jarallax/2.1.4/jarallax.min.js"></script>
<script>jQuery(document).ready(function(){jQuery('.jarallax').jarallax({ speed: 0.5});})</script>
</html>