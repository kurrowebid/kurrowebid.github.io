<li><a href="https://portal.kurro.id/login">Login</a></li>
<li><a href="https://portal.kurro.id/registration">Daftar</a></li>