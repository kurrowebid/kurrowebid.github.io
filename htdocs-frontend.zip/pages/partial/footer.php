<div class="footer">
		<div class="container">
			<div class="row">
				<div class="col-lg-4 col-md-3 col-sm-12 col-12 margin-b15">
					<a class="navbar-brand" href="https://kurro.id/">
						<img src="../assets/images/logo-kurro-white.png" class="img-responsive">
					</a>
					<small>Situs lowongan kerja dan education platform untuk jaringan kerja profesional. Saatnya mencari kerja dan perekrutan karyawan dengan mudah.</small>
					<ul class="footer--socmed">
						<li><a href=""><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
						<li><a href=""><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
						<li><a href=""><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
					</ul>
				</div>
				<div class="col-lg-8 col-md-9 col-sm-12 col-12 margin-b15">
					<div class="row panel-group">
						<div class="col-md-3 footer--menu">
							<a data-toggle="collapse" data-parent="#accordion" href="#collapse1" class="footer--subtitle">Cari Kerja</a>
							<ul id="collapse1" class="collapse in">
								<li><a href="https://kurro.id/event" class="footer--link light">Event</a></li>
								<li><a href="https://kurro.id/artikel/" class="footer--link light">Artikel</a></li>
								<li><a href="https://portal.kurro.id/registration">Daftar</a></li>
								<li><a href="https://portal.kurro.id/login">Login</a></li>
							</ul>
						</div>
						<div class="col-md-3 footer--menu">
							<a data-toggle="collapse" data-parent="#accordion" href="#collapse2" class="footer--subtitle">Kategori Pekerjaan</a>
							<ul id="collapse2" class="collapse in">
								<li><a href="https://portal.kurro.id/search?page=1&job_function_id=37&job_function_id=38&job_function_id=39" class="footer--link light">Computer/IT</a></li>
								<li><a href="https://portal.kurro.id/search?page=1&job_function_id=1&job_function_id=10&job_function_id=25&job_function_id=26&job_function_id=27&job_function_id=44" class="footer--link light">Accounting</a></li>
								<li><a href="https://portal.kurro.id/search?page=1&job_function_id=16%20&job_function_id=17%20&job_function_id=18%20&job_function_id=19%20&job_function_id=20%20&job_function_id=21%20&job_function_id=22%20&job_function_id=23%20&job_function_id=24%20&job_function_id=43%20&job_function_id=64" class="footer--link light">Engineering</a></li>
								<li><a href="https://portal.kurro.id/search?page=1&job_function_id=2&job_function_id=7&job_function_id=8" class="footer--link light">Art Media/Design</a></li>
								<li><a href="https://portal.kurro.id/search?page=1&job_function_id=54%20&job_function_id=55%20&job_function_id=56%20&job_function_id=57%20&job_function_id=58" class="footer--link light">Sales/Marketing</a></li>
								<li><a href="https://portal.kurro.id/search?page=1&job_function_id=13&job_function_id=14&job_function_id=36&job_function_id=60" class="footer--link light">Admin/Human Resources</a></li>
							
							</ul>
						</div>
						<div class="col-md-3 footer--menu">
							<a data-toggle="collapse" data-parent="#accordion" href="#collapse3" class="footer--subtitle">Pasang Iklan</a>
							<ul id="collapse3" class="collapse in">
								<li><a href="https://portal.kurro.id/company/registration" class="footer--link light">Pasang Iklan</a></li>
								<li><a href="https://kurro.id/fitur" class="footer--link light">Fitur</a></li>
								<li><a href="https://rts.kurro.id/" class="footer--link light">Login Company</a></li>
						
							</ul>
						</div>
						<div class="col-md-3 footer--menu">
							<a data-toggle="collapse" data-parent="#accordion" href="#collapse4" class="footer--subtitle">kurro.id</a>
							<ul id="collapse4" class="collapse in">
								<li><a href="https://kurro.id/about" class="footer--link light">Tentang Kami</a></li>
								<li><a href="https://kurro.id/contact" class="footer--link light">Hubungi</a></li>
								<li><a href="https://kurro.id/privacy-policy" class="footer--link light">Privacy & Policy</a></li>
								<li><a href="https://kurro.id/terms-condition" class="footer--link light">Terms & Condition</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<small>Copyright &copy; 2023. All Right Reserved</small>
				</div>
			</div>
		</div>
	</div>
</body>

<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBTeu43V4BOficz5PgyPoLNFWosb_6UnVg&callback=initMap"
  type="text/javascript"></script>
  
<script type="text/javascript" src="../assets/js/js-bundle.js"></script>
<script type="text/javascript" src="../assets/js/vendor/scrollmagic/uncompressed/ScrollMagic.js"></script>
<script type="text/javascript" src="../assets/js/vendor/scrollmagic/uncompressed/plugins/debug.addIndicators.js"></script>
<script type="text/javascript" src="../assets/js/vendor/cropper/dist/cropper.js"></script>
<script>
	$(document).ready(function(){
		$('.filter--menu .btn--primary').on('click', function(){
			$('.button-close-filter--menu').click();
		});
	});

	var image = $('#image');

	$('#select-image').change(function(){
		if(this.files && this.files[0]){
			var reader = new FileReader();

			reader.onload = function(e){
				image.attr('src', e.target.result);
				$('#change-pp-crop').on('shown.bs.modal', function(){
					showCropper(image);
				})
				$('#change-pp-crop').modal('show');
			}

			reader.readAsDataURL(this.files[0]);
		}
	})

	$('#cropImg').on('click', function(){

		var imageData = image.cropper('getCroppedCanvas').toDataURL();
		$('#imgReview img').attr('src', imageData);
		$('#imgReview').parents('.img-review-wrapper').show();
		$('#change-pp-crop').modal('hide');
		reset(image);
	})

	$('.btn-clear-upload').on('click', function(){
		console.log('clear upload');
		$('#imgReview img').attr('src', '');
		$('#select-image').val('');
		$('#imgReview').parents('.img-review-wrapper').hide();
	});


	function reset(img){
		img.cropper('destroy');
		img.val('');
	}

	function showCropper(img){
		img.cropper({
			aspectRatio: 1 / 1,
			crop: function(event) {
				console.log(event.detail.x);
				console.log(event.detail.y);
				console.log(event.detail.width);
				console.log(event.detail.height);
				console.log(event.detail.rotate);
				console.log(event.detail.scaleX);
				console.log(event.detail.scaleY);
			}
		});
	}
</script>
<!-- <script type="text/javascript" src="../assets/js/vendor/jquery.js"></script>
<script type="text/javascript" src="../assets/js/vendor/jquery.easing.min.js"></script>
<script type="text/javascript" src="../assets/js/bootstrap/bootstrap.min.js"></script>
<script type="text/javascript" src="../assets/js/vendor/swiper/js/swiper.min.js"></script>
<script type="text/javascript" src="../assets/js/vendor/air-datepicker/datepicker.min.js"></script>
<script type="text/javascript" src="../assets/js/vendor/air-datepicker/datepicker.en.js"></script>
<script type="text/javascript" src="../assets/js/vendor/matchHeight/dist/jquery.matchHeight-min.js"></script> -->

<!-- <script type="text/javascript" src="../assets/js/script.js"></script> -->
</html>