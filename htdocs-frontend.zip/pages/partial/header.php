<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" lang="en">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<title>kurro.id Portal Lowongan Kerja Online terpercaya</title>
	<meta name="author" content="">
	<meta name="keywords" content="">
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- css -->
	<link rel="stylesheet" type="text/css" href="../assets/css/core-bundle.css">
	<!-- <link rel="stylesheet" type="text/css" href="../assets/js/vendor/swiper/css/swiper.min.css">
	<link rel="stylesheet" type="text/css" href="../assets/js/vendor/air-datepicker/datepicker.css">
	<link rel="stylesheet" type="text/css" href="../assets/css/core.css"> -->
</head>
<body>
<?php include('./partial/navbar.php');?>