	<li class="dropdown dropdown--user">
						<a href="#" class="media dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
							<div class="img--user small">
								<img src="../assets/images/img-user.png" alt="" class="img-circle">
							</div>
							<div class="media-body media-middle">
								<div class="flex vcenter">
									<h6 class="s13 margin0">Johnson Dominic</h6>
									<span class="caret"></span>
								</div>
							</div>
						</a>
						<ul class="dropdown-menu">
							<li><a href="#"><i class="ico-message"></i><small>Message</small><span class="notif">1</span></a></li>
							<li><a href="#"><i class="ico-change-password"></i><small>Change Password</small></a></li>
							<li><a href="#"><i class="ico-setting"></i><small>Settings</small></a></li>
						</ul>
					</li>
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">EN <span class="caret"></span></a>
						<ul class="dropdown-menu">
							<li><a href="#">ID</a></li>
						</ul>
					</li>