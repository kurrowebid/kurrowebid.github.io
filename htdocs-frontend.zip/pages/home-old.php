<?php include('partial/header.php') ?>

<div class="content page__home">
		<!-- <div class="banner" style="background-image:url('../assets/images/img-banner.jpg')"></div> -->
		<div class="swiper-container home--slider">
			<div class="swiper-wrapper">
				<div class="swiper-slide" style="background-image:url('../assets/images/img-banner.jpg')"></div>
				<div class="swiper-slide" style="background-image:url('../assets/images/img-banner2.jpg')"></div>
				</div>
			<!-- Add Arrows -->
			<div class="swiper-button-next"></div>
			<div class="swiper-button-prev"></div>
		</div>
		<div class="jumbotron section1 margin0 home__form">
			<div class="container text-center">
				<h1 class="s38 light text-darkgrey">Find your loveable job <br> with endles possibilities.</h1>
				<h5 class="s16 spacing06 text-darkgrey margin-b15">Save time, save money, look more professional and win more clients.</h5>
				<form action="" class="form-inline">
					<div class="form-group job-position">
						<input type="text" class="form-control" placeholder="Job Position">
					</div>
					<div class="form-group job-location">
						<input type="text" class="form-control" placeholder="Job Location">
					</div>
					<input type="submit" class="btn btn--primary" value="FIND NOW">
				</form>
			</div>
		</div>
		<div class="jumbotron section2 margin0 bg--white">
			<div class="container text-center">
				<h3 class="raleway spacing4 text-blue">KATEGORI PEKERJAAN</h3>
				<br><br>
				<div class="row">
					<div class="col-md-3 col-sm-4 item__link">
						<a href="#" class="d-block">
							<div class="item__link--img">
								<div class="img" style="background-image: url(../assets/images/kategori/sprite.png);background-position: 0 0;"></div>
							</div>
							<h5 class="s15 spacing06">ACCOUNTING FINANCE / BANKING</h5>
						</a>
					</div>
					<div class="col-md-3 col-sm-4 item__link">
						<a href="#" class="d-block">
							<div class="item__link--img">
								<div class="img" style="background-image: url(../assets/images/kategori/sprite.png);background-position: -90px 0;"></div>
							</div>
							<h5 class="s15 spacing06">SALES / MARKETING</h5>
						</a>
					</div>
					<div class="col-md-3 col-sm-4 item__link">
						<a href="#" class="d-block">
							<div class="item__link--img">
								<div class="img" style="background-image: url(../assets/images/kategori/sprite.png);background-position: -180px 0;"></div>
							</div>
							<h5 class="s15 spacing06">COMPUTER / IT</h5>
						</a>
					</div>
					<div class="col-md-3 col-sm-4 item__link">
						<a href="#" class="d-block">
							<div class="item__link--img">
								<div class="img" style="background-image: url(../assets/images/kategori/sprite.png);background-position: -270px 0;"></div>
							</div>
							<h5 class="s15 spacing06">ART MEDIA / COMMUNICATIONS</h5>
						</a>
					</div>
					<div class="col-md-3 col-sm-4 item__link">
						<a href="#" class="d-block">
							<div class="item__link--img">
								<div class="img" style="background-image: url(../assets/images/kategori/sprite.png);background-position: -360px 0;"></div>
							</div>
							<h5 class="s15 spacing06">ADMIN / HUMAN RESOURCES</h5>
						</a>
					</div>
					<div class="col-md-3 col-sm-4 item__link">
						<a href="#" class="d-block">
							<div class="item__link--img">
								<div class="img" style="background-image: url(../assets/images/kategori/sprite.png);background-position: -450px 0;"></div>
							</div>
							<h5 class="s15 spacing06">CONSTRUCTION</h5>
						</a>
					</div>
					<div class="col-md-3 col-sm-4 item__link">
						<a href="#" class="d-block">
							<div class="item__link--img">
								<div class="img" style="background-image: url(../assets/images/kategori/sprite.png);background-position: -540px 0;"></div>
							</div>
							<h5 class="s15 spacing06">EDUCATION / TRAINNING</h5>
						</a>
					</div>
					<div class="col-md-3 col-sm-4 item__link">
						<a href="#" class="d-block">
							<div class="item__link--img">
								<div class="img" style="background-image: url(../assets/images/kategori/sprite.png);background-position: 0 -90px;"></div>
							</div>
							<h5 class="s15 spacing06">ENGINEERING</h5>
						</a>
					</div>
					<div class="col-md-3 col-sm-4 item__link">
						<a href="#" class="d-block">
							<div class="item__link--img">
								<div class="img" style="background-image: url(../assets/images/kategori/sprite.png);background-position: -90px -90px;"></div>
							</div>
							<h5 class="s15 spacing06">MANUFACTURING</h5>
						</a>
					</div>
					<div class="col-md-3 col-sm-4 item__link">
						<a href="#" class="d-block">
							<div class="item__link--img">
								<div class="img" style="background-image: url(../assets/images/kategori/sprite.png);background-position: -180px -90px;"></div>
							</div>
							<h5 class="s15 spacing06">HEALTHCARE</h5>
						</a>
					</div>
					<div class="col-md-3 col-sm-4 item__link">
						<a href="#" class="d-block">
							<div class="item__link--img">
								<div class="img" style="background-image: url(../assets/images/kategori/sprite.png);background-position: -270px -90px;"></div>
							</div>
							<h5 class="s15 spacing06">HOTEL / RESTAURANT</h5>
						</a>
					</div>
					<div class="col-md-3 col-sm-4 item__link">
						<a href="#" class="d-block">
							<div class="item__link--img">
								<div class="img" style="background-image: url(../assets/images/kategori/sprite.png);background-position: -360px -90px;"></div>
							</div>
							<h5 class="s15 spacing06">SCIENCE</h5>
						</a>
					</div>
				</div>
			</div>
		</div>
		<div class="jumbotron section3 margin0 bg--lightgrey">
			<div class="container text-center">
				<h3 class="raleway spacing4 text-blue">JOIN WITH PROFESSIONAL</h3>
				<br><br>
				<div class="row">
					<div class="col-md-3 col-sm-4 item__link">
						<div class="item__link--img">
							<a href="#" class="img--user">
								<img src="../assets/images/img-user.jpg" alt="" class="">
							</a>
						</div>
						<div class="btn">
							<a href="#" class=""><small class="bold text-blue2">John Smith</small></a>
							<small class="text-blue2 d-block">UI Notification Center</small>
						</div>
					</div>
					<div class="col-md-3 col-sm-4 item__link">
						<div class="item__link--img">
							<a href="#" class="img--user">
								<img src="../assets/images/img-user.jpg" alt="" class="">
							</a>
						</div>
						<div class="btn">
							<a href="#" class=""><small class="bold text-blue2">John Smith</small></a>
							<small class="text-blue2 d-block">UI Notification Center</small>
						</div>
					</div>
					<div class="col-md-3 col-sm-4 item__link">
						<div class="item__link--img">
							<a href="#" class="img--user">
								<img src="../assets/images/img-user.jpg" alt="" class="">
							</a>
						</div>
						<div class="btn">
							<a href="#" class=""><small class="bold text-blue2">John Smith</small></a>
							<small class="text-blue2 d-block">UI Notification Center</small>
						</div>
					</div>
					<div class="col-md-3 col-sm-4 item__link">
						<div class="item__link--img">
							<a href="#" class="img--user">
								<img src="../assets/images/img-user.jpg" alt="" class="">
							</a>
						</div>
						<div class="btn">
							<a href="#" class=""><small class="bold text-blue2">John Smith</small></a>
							<small class="text-blue2 d-block">UI Notification Center</small>
						</div>
					</div>
					<div class="col-md-3 col-sm-4 item__link">
						<div class="item__link--img">
							<a href="#" class="img--user">
								<img src="../assets/images/img-user.jpg" alt="" class="">
							</a>
						</div>
						<div class="btn">
							<a href="#" class=""><small class="bold text-blue2">John Smith</small></a>
							<small class="text-blue2 d-block">UI Notification Center</small>
						</div>
					</div>
					<div class="col-md-3 col-sm-4 item__link">
						<div class="item__link--img">
							<a href="#" class="img--user">
								<img src="../assets/images/img-user.jpg" alt="" class="">
							</a>
						</div>
						<div class="btn">
							<a href="#" class=""><small class="bold text-blue2">John Smith</small></a>
							<small class="text-blue2 d-block">UI Notification Center</small>
						</div>
					</div>
					<div class="col-md-3 col-sm-4 item__link">
						<div class="item__link--img">
							<a href="#" class="img--user">
								<img src="../assets/images/img-user.jpg" alt="" class="">
							</a>
						</div>
						<div class="btn">
							<a href="#" class=""><small class="bold text-blue2">John Smith</small></a>
							<small class="text-blue2 d-block">UI Notification Center</small>
						</div>
					</div>
					<div class="col-md-3 col-sm-4 item__link">
						<div class="item__link--img">
							<a href="#" class="img--user">
								<img src="../assets/images/img-user.jpg" alt="" class="">
							</a>
						</div>
						<div class="btn">
							<a href="#" class=""><small class="bold text-blue2">John Smith</small></a>
							<small class="text-blue2 d-block">UI Notification Center</small>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="jumbotron section4 margin0 bg--image" style="background-image:url('../assets/images/img-banner2.jpg')">
			<div class="container text-center">
				<h3 class="raleway spacing4 text-white">PERUSAHAAN FAVORIT</h3>
				<br><br>
				<div class="row">
					<div class="col-md-3 col-sm-4 item__link">
						<a href="#" class="d-block">
							<div class="item__link--img img-hover" style="background-image:url(../assets/images/warner-bros.png)" data-hover="../assets/images/microsoft.png" data-unhover="../assets/images/warner-bros.png"></div>
						</a>
					</div>
					<div class="col-md-3 col-sm-4 item__link">
						<a href="#" class="d-block">
							<div class="item__link--img img-hover" style="background-image:url(../assets/images/warner-bros.png)" data-hover="../assets/images/microsoft.png" data-unhover="../assets/images/warner-bros.png"></div>
						</a>
					</div>
					<div class="col-md-3 col-sm-4 item__link">
						<a href="#" class="d-block">
							<div class="item__link--img img-hover" style="background-image:url(../assets/images/warner-bros.png)" data-hover="../assets/images/microsoft.png" data-unhover="../assets/images/warner-bros.png"></div>
						</a>
					</div>
					<div class="col-md-3 col-sm-4 item__link">
						<a href="#" class="d-block">
							<div class="item__link--img img-hover" style="background-image:url(../assets/images/warner-bros.png)" data-hover="../assets/images/microsoft.png" data-unhover="../assets/images/warner-bros.png"></div>
						</a>
					</div>
				</div>
			</div>
			<br><br>
			<div class="container text-center">
				<h3 class="raleway spacing4 text-white">UNIVERSITAS PILIHAN</h3>
				<br><br>
				<div class="row">
					<div class="col-md-3 col-sm-4 item__link">
						<a href="#" class="d-block">
							<div class="item__link--img img-hover" style="background-image:url(../assets/images/warner-bros.png)" data-hover="../assets/images/microsoft.png" data-unhover="../assets/images/warner-bros.png"></div>
						</a>
					</div>
					<div class="col-md-3 col-sm-4 item__link">
						<a href="#" class="d-block">
							<div class="item__link--img img-hover" style="background-image:url(../assets/images/warner-bros.png)" data-hover="../assets/images/microsoft.png" data-unhover="../assets/images/warner-bros.png"></div>
						</a>
					</div>
					<div class="col-md-3 col-sm-4 item__link">
						<a href="#" class="d-block">
							<div class="item__link--img img-hover" style="background-image:url(../assets/images/warner-bros.png)" data-hover="../assets/images/microsoft.png" data-unhover="../assets/images/warner-bros.png"></div>
						</a>
					</div>
					<div class="col-md-3 col-sm-4 item__link">
						<a href="#" class="d-block">
							<div class="item__link--img img-hover" style="background-image:url(../assets/images/warner-bros.png)" data-hover="../assets/images/microsoft.png" data-unhover="../assets/images/warner-bros.png"></div>
						</a>
					</div>
				</div>
			</div>
		</div>
		<div class="jumbotron section5 margin0">
			<div class="container">
				<h3 class="raleway spacing4 text-blue text-center">ARTIKEL</h3>
				<br><br>
				<div class="row">
					<div class="col-sm-6 col-md-4 col-lg-3">
						<div class="thumbnail">
							<a href="#" class="d-block">
								<div class="img" style="background-image:url(../assets/images/img-thumb2.jpg)"></div>
							</a>
							<div class="caption">
								<a href="#"><h6 class="raleway bold spacing2 uppercase margin-b5">Montana</h6></a>
								<div class="match-height">
									<h6 class="s13 margin0">Without music, life would be a mistake.</h6>
								</div>
								<hr class="margin0">
								<div class="media">
									<div class="media-left media-middle">
										<a href="#" class="d-block">
											<img class="media-object img-circle" src="../assets/images/img-user.png" alt="...">
										</a>
									</div>
									<div class="media-body">
										<a href="#"><h6 class="media-heading raleway spacing2 uppercase bold">Paul Rand</h6></a>
										<h6 class="s13 margin0">Art Director, Designer</h6>
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- <div class="col-sm-6 col-md-4 col-lg-3">
						<div class="thumbnail">
							<a href="#"><img src="../assets/images/img-thumb2.jpg" alt="..."></a>
							<div class="caption">
								<a href="#"><h6 class="raleway bold spacing2 uppercase margin-b5">Montana</h6></a>
								<div class="match-height">
									<h6 class="s13 margin0">Without music, life would be a mistake.</h6>
								</div>
								<hr class="margin0">
								<div class="media">
									<div class="media-left media-middle">
										<a href="#" class="d-block">
											<img class="media-object img-circle" src="../assets/images/img-user.png" alt="...">
										</a>
									</div>
									<div class="media-body">
										<a href="#"><h6 class="media-heading raleway spacing2 uppercase bold">Paul Rand</h6></a>
										<h6 class="s13 margin0">Art Director, Designer</h6>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-sm-6 col-md-4 col-lg-3">
						<div class="thumbnail">
							<a href="#"><img src="../assets/images/img-thumb2.jpg" alt="..."></a>
							<div class="caption">
								<a href="#"><h6 class="raleway bold spacing2 uppercase margin-b5">Montana</h6></a>
								<div class="match-height">
									<h6 class="s13 margin0">Without music, life would be a mistake.</h6>
								</div>
								<hr class="margin0">
								<div class="media">
									<div class="media-left media-middle">
										<a href="#" class="d-block">
											<img class="media-object img-circle" src="../assets/images/img-user.png" alt="...">
										</a>
									</div>
									<div class="media-body">
										<a href="#"><h6 class="media-heading raleway spacing2 uppercase bold">Paul Rand</h6></a>
										<h6 class="s13 margin0">Art Director, Designer</h6>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-sm-6 col-md-4 col-lg-3">
						<div class="thumbnail">
							<a href="#"><img src="../assets/images/img-thumb.png" alt="..."></a>
							<div class="caption">
								<a href="#"><h6 class="raleway bold spacing2 uppercase margin-b5">Montana</h6></a>
								<div class="match-height">
									<h6 class="s13 margin0">Without music, life would be a mistake.</h6>
								</div>
								<hr class="margin0">
								<div class="media">
									<div class="media-left media-middle">
										<a href="#" class="d-block">
											<img class="media-object img-circle" src="../assets/images/img-user.png" alt="...">
										</a>
									</div>
									<div class="media-body">
										<a href="#"><h6 class="media-heading raleway spacing2 uppercase bold">Paul Rand</h6></a>
										<h6 class="s13 margin0">Art Director, Designer</h6>
									</div>
								</div>
							</div>
						</div>
					</div> -->
				</div>
			</div>
		</div>
	</div>

<?php include('partial/footer.php') ?>