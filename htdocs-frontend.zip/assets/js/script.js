var w = window,
        d = document,
        e = d.documentElement,
        g = d.getElementsByTagName('body')[0],
        widthviewport = w.innerWidth || e.clientWidth || g.clientWidth,
        heightviewport = w.innerHeight || e.clientHeight || g.clientHeight;

function togglePanel (){
   var w = $(window).width();
   if (w <= 768) {
      $('.footer--menu ul').removeClass('in');
   } else {
      $('.footer--menu ul').addClass('in');
   }
}

$(window).resize(function(){
     togglePanel();
});

togglePanel();
matchHeight();

$(document).ready(function(){
  // SLIDER BANNER HOME
	var swiper = new Swiper('.home--slider', {
    paginationClickable: true,
    effect: 'fade',
    pagination: '.swiper-pagination',
    spaceBetween: 30,
    loop: true,
    autoplay: 8000,
  });
 
 // SLIDER BANNER ARTIKEL
  var swiper = new Swiper('.article--slider', {
    pagination: '.swiper-pagination',
    paginationClickable: true,
    loop: true,
    autoplay: 10000,
  });
  var swiper = new Swiper('.article--slider2', {
    pagination: '.swiper-pagination',
    paginationClickable: true,
    loop: true,
    autoplay: 10000,
  });


  // STYLE HOVER CHANGE IMAGE IN HOME
  $('.img-hover').mouseover(function () {
    $(this).css('background-image', 'url(' + $(this).data('hover') + ')');
  });

   $('.img-hover').mouseleave(function () {
    $(this).css('background-image', 'url(' + $(this).data('unhover') + ')');
  });

   // DATEPICKER
   $('.datepick').datepicker({
      language: 'en',
      dateFormat: 'dd MM yyyy',
      navTitles: {days: 'MM <i>yyyy</i>'},
      autoClose: true,
      toggleSelected: false
    });


  // DROPDOWN FILTER
  $('.search-panel .dropdown-menu').find('a').click(function(e) {
    e.preventDefault();
    var param = $(this).attr("href").replace("#","");
    var concept = $(this).text();
    $('.search-panel span#search_concept').text(concept);
    $('.input-group #search_param').val(param);
  });

imgThumbnailGallery()

})


function matchHeight(){
    $('.match-height').matchHeight();
}

function imgThumbnailGallery(){
  var utility = (function() {
    var a = {};
    a.loadResource = function(b, c) {
      if (b != null) {
        c = typeof c !== "undefined" ? c : "data-original";
        if (typeof b.attr(c) !== "undefined") {
          b.attr("src", b.attr(c))
        }
      }
    };
    a.loadBackgroundResource = function(b, c) {
      if (b != null) {
        c = typeof c !== "undefined" ? c : "data-original";
        if (typeof b.attr(c) !== "undefined") {
          b.css("background-image", "url(" + b.attr(c) + ")")
        }
      }
    };
    a.loadPixelTrackerResource = function(b, c, e) {
      if (b != null) {
        c = typeof c !== "undefined" ? c : "data-original";
        if (typeof b.attr(c) !== "undefined") {
          var d = b.attr(c);
          if (e.length > 0) {
            d = d + e
          }
          b.attr("src", d)
        }
      }
    };
    a.loadResources = function(c, b) {
      if (c != null) {
        b = typeof b !== "undefined" ? b : "data-original";
        c.each(function() {
          if (typeof $(this).attr(b) !== "undefined") {
            $(this).attr("src", $(this).attr(b))
          }
        })
      }
    };
    a.retrieveJSON = function(b, d, c) {
      $.getJSON(b, d, c)
    };
    a.getCurrentPath = function() {
      return $(location).attr("protocol") + "//" + $(location).attr("host") + $(location).attr("pathname")
    };
    a.panelUrlProcess = function() {
      var b = document.URL.split("?").length > 1 ? "?" + document.URL.split("?")[1] : "";
      return utility.getCurrentPath() + "/panels" + b
    };
    a.getCookie = function(e) {
      var d = e + "=";
      var b = document.cookie.split(";");
      for (var f = 0; f < b.length; f++) {
        var g = b[f];
        while (g.charAt(0) == " ") {
          g = g.substring(1)
        }
        if (g.indexOf(d) == 0) {
          return decodeURIComponent(g.substring(d.length, g.length).replace(/\+/g, " "))
        }
      }
      return ""
    };
    return a
  }());

  $(".gallery--preview--thumb > li > img").click(function() {
    var h = $("#gallery--preview--image");
    var f = $("#main-vid");
    if ($(this).attr("title") == "Video") {
      h.fadeOut(0);
      utility.loadResource(f, "data-video");
      f.fadeIn(200)
    } else {
      h.fadeOut(0);
      h.css("background-image", "url(" + $(this).attr("src").replace("thumb/", "") + ")");
      h.attr("title", $(this).attr("title"));
      h.fadeIn(400);
      h.show();
      f.fadeOut(1);
      h.attr("class", "")
    }
    return false
  });
}

var ismap = document.getElementsByClassName('map');   
if (ismap.length > 0){

function initMap() {

   var here = {lat: -6.215790, lng: 106.828211};
   var map = new google.maps.Map(document.getElementById('map'), {
    zoom: 16,
    center: here,
    disableDefaultUI: true
   });
    var marker = new google.maps.Marker({
    position: here,
    map: map
   });
  }
  
}

(function(){
   $('.btn[data-toggle=modal]').on('click', function(){
    var $btn = $(this);
    var currentDialog = $btn.closest('.modal-dialog'),
    targetDialog = $($btn.attr('data-target'));;
    if (!currentDialog.length)
      return;
    targetDialog.data('previous-dialog', currentDialog);
    currentDialog.addClass('aside');
    var stackedDialogCount = $('.modal.stacked.in .modal-dialog.aside').length;
    if (stackedDialogCount <= 5){
      currentDialog.addClass('aside-' + stackedDialogCount);
    }
  });

   $('.modal.stacked').on('hide.bs.modal', function(){
    var $dialog = $(this);  
    var previousDialog = $dialog.data('previous-dialog');
    console.log(previousDialog);
    if (previousDialog){
      previousDialog.removeClass('aside');
      $dialog.data('previous-dialog', undefined);
    }
  });


})();